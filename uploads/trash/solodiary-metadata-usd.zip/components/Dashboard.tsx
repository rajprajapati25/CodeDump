import React, { useState, useEffect, useRef, useMemo } from 'react';
import CalendarView from './CalendarView';
import LineGraph from './LineGraph';
import QuickPopData from './QuickPopData';
import { ActivityEntry, Goal } from '../types';
import { TrendingUp, Award, Clock, Edit2, Trash2, Star, Banknote, Eye, EyeOff, Target, Calendar, Paperclip, Snowflake , ChartLine, ScrollText, Check, X as CloseIcon, ChevronLeft, ChevronRight, Sun, MoonStar, CloudSun, CloudMoon, Cloud, Wind, CloudDrizzle, CloudRain, CloudHail, CloudSnow, CloudLightning, Moon, Bubbles , type LucideIcon, ThermometerSun, Cloudy, Droplets } from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { getCurrencySymbol, getAggregateCurrencyDisplay } from '../constants';

const LiveClock: React.FC = React.memo(() => {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  return (
    <div className="text-5xl font-digital leading-none tracking-widest text-gray-900 dark:text-white" style={{ fontFamily: "'DigitalDismay', monospace" }}>
      {now.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      }).toUpperCase()}
    </div>
  );
});

interface TextFixingProps {
  text: string;
  className?: string;
  speed?: number;
  loop?: boolean;
}

const TextFixing: React.FC<TextFixingProps> = ({ text, className = '', speed = 40, loop = false }) => {
  const [index, setIndex] = useState(0);
  const [displayCursor, setDisplayCursor] = useState(true);

  useEffect(() => {
    let mounted = true;
    setIndex(0);
    setDisplayCursor(true);

    const tick = () => {
      let i = 0;
      const id = setInterval(() => {
        if (!mounted) return clearInterval(id);
        i += 1;
        setIndex(i);
        if (i >= text.length) {
          clearInterval(id);
          if (loop) {
            setTimeout(() => {
              if (mounted) tick();
            }, 800);
          } else {
            setDisplayCursor(false);
          }
        }
      }, speed);
    };

    if (!text || text.length === 0) {
      setIndex(0);
      setDisplayCursor(false);
    } else {
      tick();
    }

    return () => { mounted = false; };
  }, [text, speed, loop]);

  return (
    <h2 className={className}>
      {text.slice(0, index)}
      <span className={`inline-block w-1 align-middle ml-1 bg-current ${displayCursor ? 'animate-pulse' : 'opacity-0'}`} style={{ height: '1em' }} />
    </h2>
  );
};

interface DashboardProps {
  userName: string;
  entries: ActivityEntry[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
  onEdit: (entry: ActivityEntry) => void;
  onDelete: (id: string) => void;
  onUpdateUserName: (newName: string) => void;
  goals?: Goal[];
  currentTimeClass: string;
}

const weatherIconFromCode = (code: number | null, isDay: boolean): LucideIcon => {
  if (code === 0) return isDay ? Sun : MoonStar;
  if (code === 1 || code === 2) return isDay ? CloudSun : CloudMoon;
  if (code === 3) return isDay ? Cloud : CloudMoon;
  if ([45, 48].includes(code || -1)) return Wind;
  if ([51, 53, 55, 56, 57].includes(code || -1)) return CloudDrizzle;
  if ([61, 63, 65, 80, 81, 82].includes(code || -1)) return CloudRain;
  if ([66, 67, 96, 99].includes(code || -1)) return CloudHail;
  if ([71, 73, 75, 77, 85, 86].includes(code || -1)) return CloudSnow;
  if (code === 95) return CloudLightning;
  return Cloud;
};

const Dashboard: React.FC<DashboardProps> = ({ userName, entries, selectedDate, onSelectDate, onEdit, onDelete, onUpdateUserName, goals = [], currentTimeClass }) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [editNameValue, setEditNameValue] = useState(userName);
  const [weatherCode, setWeatherCode] = useState<number | null>(null);
  const [isDayWeather, setIsDayWeather] = useState(true);
  const nameInputRef = useRef<HTMLInputElement>(null);
  const coordsRef = useRef<{ latitude: number; longitude: number } | null>(null);
  const activitiesSectionRef = useRef<HTMLDivElement>(null);
  const activityRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [showLabels, setShowLabels] = useState(true);
  const shouldReduceMotion = useReducedMotion();

  const scrollToActivity = (entryId: string, date?: string) => {
    if (date) {
      onSelectDate(date);

      setTimeout(() => {
        activitiesSectionRef.current?.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });

        setTimeout(() => {
          activityRefs.current?.[entryId]?.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
          });
        }, 400);
      }, 300);

      return;
    }

    activityRefs.current?.[entryId]?.scrollIntoView({
      behavior: 'smooth',
      block: 'center'
    });
  };

  const [popDataConfig, setPopDataConfig] = useState<{
    isOpen: boolean;
    type: 'daily' | 'monthly_pts' | 'yearly_pts' | 'yearly_goals' | 'financial' | 'profile';
  }>({
    isOpen: false,
    type: 'daily'
  });

  const openQuickPop = (type: 'daily' | 'monthly_pts' | 'yearly_pts' | 'yearly_goals' | 'financial' | 'profile') => {
    setPopDataConfig({ isOpen: true, type });
  };

  useEffect(() => {
    if (isEditingName && nameInputRef.current) {
      nameInputRef.current.focus();
    }
  }, [isEditingName]);

  const handleSaveName = () => {
    if (editNameValue.trim() && editNameValue.trim() !== userName) {
      onUpdateUserName(editNameValue.trim());
    }
    setIsEditingName(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSaveName();
    if (e.key === 'Escape') {
      setEditNameValue(userName);
      setIsEditingName(false);
    }
  };

  const handlePrevDate = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    onSelectDate(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`);
  };

  const handleNextDate = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    onSelectDate(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`);
  };

const dateObj = useMemo(() => {
  const d = new Date(selectedDate);
  return isNaN(d.getTime()) ? new Date() : d;
}, [selectedDate]);
const selectedYear = dateObj.getFullYear();
  const selectedMonthStr = selectedDate.substring(0, 7);

  const selectedDateEntries = useMemo(() =>
    entries.filter(e => e.toDate === selectedDate).sort((a, b) => a.toTime.localeCompare(b.toTime)),
    [entries, selectedDate]
  );

  const totalPointsSelectedDay = useMemo(() => selectedDateEntries.reduce((sum, e) => sum + e.points, 0), [selectedDateEntries]);
  const dailyTarget = 100;
  const dailyProgressPercent = Math.min((totalPointsSelectedDay / dailyTarget) * 100, 100);

  const daysInMonth = useMemo(() => new Date(selectedYear, dateObj.getMonth() + 1, 0).getDate(), [selectedYear, dateObj]);
  const monthTarget = daysInMonth * 100;

  const monthEntries = useMemo(() => entries.filter(e => e.toDate.startsWith(selectedMonthStr)), [entries, selectedMonthStr]);
  const totalMonthPoints = useMemo(() => monthEntries.reduce((sum, e) => sum + e.points, 0), [monthEntries]);
  const monthProgressPercent = (totalMonthPoints / monthTarget) * 100;

  const totalMonthDebit = useMemo(() => monthEntries.reduce((sum, e) => sum + (e.debit || 0), 0), [monthEntries]);
  const totalMonthCredit = useMemo(() => monthEntries.reduce((sum, e) => sum + (e.credit || 0), 0), [monthEntries]);
  const monthCashBalance = totalMonthCredit - totalMonthDebit;

const yearlyEntries = useMemo(
  () => entries.filter(e => {
    try {
      return new Date(e.toDate).getFullYear() === selectedYear;
    } catch {
      return false;
    }
  }),
  [entries, selectedYear]
);

const totalYearlyPoints = useMemo(
  () => yearlyEntries.reduce((s, e) => s + (e.points || 0), 0),
  [yearlyEntries]
);
  const yearlyGoalsAchieved = useMemo(() => goals.filter(g => g.achievedAt && new Date(g.achievedAt).getFullYear() === selectedYear).length, [goals, selectedYear]);

  // Optimized graphData dependency calculation
  const graphData = useMemo(() => {
    const data = [];
    const firstDay = new Date(selectedYear, dateObj.getMonth(), 1);
    const lastDay = new Date(selectedYear, dateObj.getMonth() + 1, 0);
    const current = new Date(firstDay);

    while (current <= lastDay) {
      const dStr = `${current.getFullYear()}-${String(current.getMonth() + 1).padStart(2, '0')}-${String(current.getDate()).padStart(2, '0')}`;
      const pts = entries.filter(e => e.toDate === dStr).reduce((sum, e) => sum + e.points, 0);
      const achievedInDay = goals.filter(g => g.achievedAt === dStr);
      data.push({
        day: current.getDate(),
        points: pts,
        fullDate: dStr,
        achievedGoals: achievedInDay
      });
      current.setDate(current.getDate() + 1);
    }
    return data;
  }, [entries, goals, selectedMonthStr, selectedYear, dateObj]);

  const monthName = dateObj.toLocaleString('default', { month: 'long' });
  const monthNameShort = dateObj.toLocaleString('default', { month: 'short' });
  const formattedTrackingDate = dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
  const formattedActivitiesDate = dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' });
  const formattedFullActivitiesDate = dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });

  const WeatherIcon = weatherIconFromCode(weatherCode, isDayWeather);
  const fallbackHour = new Date().getHours();
  const fallbackMinuteBucket = Math.floor(new Date().getMinutes() / 15) % 3;
  const fallbackIsDay = fallbackHour >= 6 && fallbackHour < 18;
  const fallbackIcon: LucideIcon = fallbackIsDay
    ? (fallbackMinuteBucket === 0 ? Sun : fallbackMinuteBucket === 1 ? CloudSun : Cloud)
    : (fallbackMinuteBucket === 0 ? MoonStar : fallbackMinuteBucket === 1 ? CloudMoon : Cloud);
  const DisplayWeatherIcon = weatherCode === null ? fallbackIcon : WeatherIcon;

  useEffect(() => {
    let disposed = false;
    const fetchWeather = async (latitude: number, longitude: number) => {
      try {
        const weatherRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=weather_code,is_day&timezone=auto`);
        if (!weatherRes.ok) throw new Error('Weather request failed');
        const weatherData = await weatherRes.json();
        const current = weatherData?.current;
        if (disposed || !current) return;
        setWeatherCode(typeof current.weather_code === 'number' ? current.weather_code : null);
        setIsDayWeather(current.is_day === 1);
      } catch {
        if (!disposed) setWeatherCode(null);
      }
    };

    const fetchCoordsByIP = async () => {
      try {
        const ipRes = await fetch('https://ipapi.co/json/');
        if (!ipRes.ok) throw new Error('IP lookup failed');
        const ipData = await ipRes.json();
        const latitude = Number(ipData?.latitude);
        const longitude = Number(ipData?.longitude);
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) throw new Error('Invalid coordinates');
        coordsRef.current = { latitude, longitude };
        await fetchWeather(latitude, longitude);
      } catch {
        if (!disposed) setWeatherCode(null);
      }
    };

    const refresh = () => {
      if (coordsRef.current) {
        fetchWeather(coordsRef.current.latitude, coordsRef.current.longitude);
        return;
      }
      fetchCoordsByIP();
    };

    refresh();
    const timer = setInterval(refresh, 30 * 60 * 1000);
    return () => {
      disposed = true;
      clearInterval(timer);
    };
  }, []);

  return (
    <div className="md:space-y-6 space-y-2.5">
{/* 1. Moved onClick to the main wrapper div so clicking the layout or bg triggers the profile popup.
        2. Added 'overflow-hidden' to ensure the background icon patch doesn't break rounded corners.
        3. Added 'cursor-pointer group/card' to signal a clickable section.
      */}
      <div 
        onClick={() => openQuickPop('profile')}
        className={`relative flex flex-col md:flex-row items-center justify-between md:gap-6 gap-3 mb-4 bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm overflow-hidden cursor-pointer group/card transition-all duration-300 hover:shadow-md ${currentTimeClass}`}
      >
        
        {/* AMBIENT BACKGROUND WEATHER ENVIRONMENT */}
        <div className="absolute inset-0 pointer-events-none select-none z-0">
          
          {/* ==================== RIGHT SIDE: MAIN ICON (SIMPLE FADE IN AFTER 2s) ==================== */}
          {/* Only this main icon has a gentle fade-in transition after 2 seconds */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.0, delay: 2, ease: "linear" }}
            className="absolute right-6 top-1/2 -translate-y-1/2 opacity-15 text-slate-400 dark:text-slate-500 transition-transform duration-700 group-hover/card:scale-110 group-hover/card:rotate-6"
          >
            <DisplayWeatherIcon size={120} className="w-auto h-auto" />
          </motion.div>

          {/* ==================== COMPLETELY STATIC CANVAS ELEMENTS (INSTANT / RANDOMIZED) ==================== */}
          {/* These icons load instantly, have no animations, and are distributed across the layout with varying scales */}
          
          {/* Top-Left: Bright Sun Element */}
          <div className="absolute left-[5%] top-[5%] opacity-25 dark:opacity-45 text-amber-500 dark:text-amber-400 scale-[1.15] transition-transform duration-700 group-hover/card:rotate-12">
            <Sun size={40} />
          </div>

          {/* Lower Mid-Left: Small Cozy Moon */}
          <div className="absolute left-[30%] bottom-[7%] opacity-20 dark:opacity-15 text-indigo-400 dark:text-indigo-300 scale-[0.85] transition-transform duration-1000 group-hover/card:-translate-y-0.5">
            <Wind size={35} />
          </div>
          
          <div className="absolute right-[0%] bottom-[0%] opacity-15 dark:opacity-15 text-indigo-400 dark:text-indigo-300 scale-[0.85] transition-transform duration-1000 group-hover/card:-translate-y-0.5">
            <Droplets size={35} />
          </div>
          
          {/* Lower Mid-Left: Small Cozy Moon */}
          <div className="absolute left-[-5%] bottom-[-20%] opacity-20 dark:opacity-15 text-indigo-400 dark:text-indigo-300 scale-[0.85] transition-transform duration-1000 group-hover/card:-translate-y-0.5">
            <CloudMoon size={90} />
          </div>

          {/* Upper Center-Left: Large Ambient Cloud */}
          <div className="absolute left-[45%] top-[18%] opacity-25 dark:opacity-45 text-slate-400 dark:text-slate-500 scale-[1.3] transition-transform duration-700 group-hover/card:translate-x-2">
            <Snowflake size={44} />
          </div>

          {/* Top Far-Right: Medium Cloud Patch */}
          <div className="absolute right-[32%] top-[8%] opacity-20 dark:opacity-10 text-slate-400 dark:text-slate-500 scale-[0.95]">
            <Cloudy size={32} />
          </div>
          
          {/* Top Far-Right: Medium Cloud Patch */}
          <div className="absolute right-[0%] top-[0%] opacity-20 dark:opacity-10 text-slate-400 dark:text-slate-500 scale-[0.95]">
            <ThermometerSun size={50} />
          </div>

          {/* Bottom Near-Right: Small Rain Element near the main background track */}
          <div className="absolute right-[22%] bottom-[10%] opacity-15 dark:opacity-[0.07] text-slate-400 dark:text-slate-500 scale-[0.75]">
            <CloudRain size={28} />
          </div>
        </div>

        {/* Text Container - Brought forward with z-10 so it sits nicely over the background icons */}
        <div className="text-center md:text-left flex-1 z-10 w-full">
          <AnimatePresence mode="wait" initial={false}>
            {isEditingName ? (
              <motion.div
                key="editing"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2, ease: 'easeOut' }}
                // stopPropagation prevents opening the profile popup while trying to type inside the input
                onClick={(e) => e.stopPropagation()}
                className="flex items-center gap-2 justify-center md:justify-start"
              >
                <input
                  ref={nameInputRef}
                  type="text"
                  value={editNameValue}
                  onChange={(e) => setEditNameValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="w-[70%] md:w-auto md:min-w-[320px] text-2xl font-black uppercase tracking-tight bg-white/20 dark:bg-black/20 border-b-2 border-blue-600 outline-none text-gray-900 dark:text-white px-2 py-1 rounded-t-lg"
                />
                <motion.button 
                  whileTap={{ scale: 0.92 }} 
                  onClick={(e) => { e.stopPropagation(); handleSaveName(); }} 
                  className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
                >
                  <Check size={20} />
                </motion.button>
                <motion.button 
                  whileTap={{ scale: 0.92 }} 
                  onClick={(e) => { e.stopPropagation(); setEditNameValue(userName); setIsEditingName(false); }} 
                  className="p-2 bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-white rounded-full hover:bg-gray-300 transition-colors"
                >
                  <CloseIcon size={20} />
                </motion.button>
              </motion.div>
            ) : (
              <motion.div 
                key="viewing" 
                initial={{ opacity: 0, y: 8 }} 
                animate={{ opacity: 1, y: 0 }} 
                exit={{ opacity: 0, y: -8 }} 
                transition={{ duration: 0.2, ease: 'easeOut' }} 
                className="flex items-center gap-3 justify-center md:justify-start group text-left"
              >
                <div className="text-left select-none">
                  <TextFixing text={userName} className="text-3xl md:text-4xl font-black uppercase tracking-tight group-hover/card:underline decoration-dotted decoration-2 text-gray-900 dark:text-white" />
                </div>
                
                <motion.button 
                  whileTap={{ scale: 0.9 }} 
                  onClick={(e) => { e.stopPropagation(); setIsEditingName(true); }} 
                  className="w-0 md:w-auto md:p-1.5 p-0 opacity-0 group-hover:opacity-100 text-gray-400 hover:text-blue-500 transition-all focus:opacity-100" 
                  title="Edit name"
                >
                  <Edit2 size={18} />
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
          <p className="text-sm font-medium mt-2">
            <span className="text-blue-600 dark:text-blue-400 font-bold">Tracking data:</span>
            <span className="ml-2 font-bold text-gray-700 dark:text-gray-300">{formattedTrackingDate}</span>
          </p>
        </div>

        {/* Right column: Live Clock wrapper
          - Hidden entirely on mobile screens (hidden) and turns visible on desktops/tablets (md:block)
          - Brought forward with z-10 to retain high visual stacking placement over background icons
        */}
        <div className="hidden md:block z-10 w-full md:w-auto text-center md:text-right">
          <div 
            onClick={(e) => e.stopPropagation()} // Prevents clock interaction from firing the parent card's popup action
            className="p-2 pr-5 pl-5 rounded-2xl min-w-[230px] text-center bg-white/20 dark:bg-black/20 backdrop-blur-lg border border-white/30 dark:border-white/10 shadow-xl transition-all duration-700 hover:scale-105"
          >
            <LiveClock />
          </div>
        </div>
      </div>

<div className="grid grid-cols-1 lg:grid-cols-2 md:gap-6 gap-3">
  {/* Today's Points Card */}
  <div 
    onClick={() => openQuickPop('daily')} 
    className="relative overflow-hidden bg-white dark:bg-slate-800 md:p-6 p-3 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 cursor-pointer hover:border-emerald-500/40 transition-all group"
  >
    {/* Large Background Icon */}
    <Target className="absolute -left-4 -bottom-4 text-emerald-500 opacity-10 dark:opacity-10 pointer-events-none transform group-hover:scale-110 transition-transform duration-500" size={120} />
    
    <div className="relative z-10 flex justify-between items-center mb-4">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-emerald-500/10"><Target className="text-emerald-500" size={20} /></div>
        <div>
          <h3 className="text-xl font-bold uppercase tracking-tight text-gray-800 dark:text-white">Today's Points</h3>
          <p className="text-xs text-gray-500">Daily Target: 100 pts</p>
        </div>
      </div>
      <div className="text-right">
        <span className="text-4xl font-black text-emerald-600 leading-none font-digital">{totalPointsSelectedDay}</span>
        <span className="text-xs font-bold text-gray-400 ml-1">pts</span>
      </div>
    </div>
    <div className="relative z-10 w-full h-4 bg-gray-100 dark:bg-slate-900 rounded-full overflow-hidden p-1 border border-gray-200 dark:border-slate-700 shadow-inner">
      <div className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-full transition-all duration-1000 shadow-lg" style={{ width: `${dailyProgressPercent}%` }} />
    </div>
  </div>

  {/* Monthly Progress Card */}
  <div 
    onClick={() => openQuickPop('monthly_pts')} 
    className="relative overflow-hidden bg-white dark:bg-slate-800 md:p-6 p-3 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 cursor-pointer hover:border-blue-500/40 transition-all group"
  >
    {/* Large Background Icon */}
    <Calendar className="absolute -left-4 -bottom-4 text-blue-500 opacity-10 dark:opacity-10 pointer-events-none transform group-hover:scale-110 transition-transform duration-500" size={120} />
    
    <div className="relative z-10 flex justify-between items-center mb-4">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-blue-500/10"><Calendar className="text-blue-500" size={20} /></div>
        <div>
          <h3 className="text-xl font-bold uppercase tracking-tight text-gray-800 dark:text-white">Monthly Progress</h3>
          <p className="text-xs text-gray-500">{monthName} Target: {monthTarget.toLocaleString()} pts</p>
        </div>
      </div>
      <div className="text-right">
        <span className="text-4xl font-black text-blue-600 leading-none font-digital">{monthProgressPercent.toFixed(0)}</span>
        <span className="text-1xl font-black text-gray-400 leading-none">%</span>
      </div>
    </div>
    <div className="relative z-10 w-full h-4 bg-gray-100 dark:bg-slate-900 rounded-full overflow-hidden p-1 border border-gray-200 dark:border-slate-700 shadow-inner">
      <div className="h-full bg-gradient-to-r from-blue-600 via-blue-400 to-emerald-400 rounded-full transition-all duration-1000 shadow-lg" style={{ width: `${Math.min(monthProgressPercent, 100)}%` }} />
    </div>
  </div>
</div>

<div className="grid grid-cols-2 lg:grid-cols-4 md:gap-4 gap-3">
  {/* Yearly Points Card */}
  <div 
    onClick={() => openQuickPop('yearly_pts')} 
    className="relative overflow-hidden bg-white dark:bg-slate-800 md:p-5 p-2.5 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all group"
  >
    {/* Large Background Icon */}
    <TrendingUp className="absolute -right-2 -bottom-2 text-blue-500 opacity-10 dark:opacity-10 pointer-events-none transform group-hover:scale-110 transition-transform duration-500" size={90} />
    
    <div className="relative z-10 flex items-center gap-3 mb-2">
      <div className="p-2 rounded-lg bg-blue-500/10"><TrendingUp className="text-blue-500" size={18} /></div>
      <p className="text-[10px] font-bold uppercase text-gray-400">Yearly Points ({selectedYear})</p>
    </div>
    <p className="relative z-10 text-2xl font-black text-gray-800 dark:text-white">{totalYearlyPoints.toLocaleString()}</p>
  </div>

  {/* Yearly Goals Card */}
  <div 
    onClick={() => openQuickPop('yearly_goals')} 
    className="relative overflow-hidden bg-white dark:bg-slate-800 md:p-5 p-2.5 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all group"
  >
    {/* Large Background Icon */}
    <Award className="absolute -right-2 -bottom-2 text-purple-500 opacity-10 dark:opacity-10 pointer-events-none transform group-hover:scale-110 transition-transform duration-500" size={90} />
    
    <div className="relative z-10 flex items-center gap-3 mb-2">
      <div className="p-2 rounded-lg bg-purple-500/10"><Award className="text-purple-500" size={18} /></div>
      <p className="text-[10px] font-bold uppercase text-gray-400">Yearly Goals ({selectedYear})</p>
    </div>
    <p className="relative z-10 text-2xl font-black text-gray-800 dark:text-white">{yearlyGoalsAchieved}</p>
  </div>

  {/* Transaction Card */}
  <div 
    onClick={() => openQuickPop('financial')} 
    className="relative overflow-hidden bg-white dark:bg-slate-800 md:p-5 p-2.5 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col justify-between col-span-2 lg:col-span-2 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all group"
  >
    {/* Large Background Icon */}
    <Banknote className="absolute -right-4 -bottom-6 text-emerald-500 opacity-10 dark:opacity-10 pointer-events-none transform group-hover:scale-110 transition-transform duration-500" size={130} />
    
    <div className="relative z-10 flex items-center justify-between mb-2">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-emerald-500/10"><Banknote className="text-emerald-500" size={18} /></div>
        <p className="text-[10px] font-bold uppercase text-gray-400">Transaction of {monthName}</p>
      </div>
      <div>
        <p className={`text-xl font-black ${monthCashBalance >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
          {getCurrencySymbol(getAggregateCurrencyDisplay(monthEntries))} {monthCashBalance.toLocaleString()}
        </p>
      </div>
    </div>
    <div className="relative z-10 flex gap-4">
      <div className="flex-1 bg-gray-50 dark:bg-slate-900/50 p-2 rounded-xl border border-gray-100 dark:border-slate-700">
        <p className="text-[9px] font-bold text-gray-400 uppercase">Total Debit</p>
        <p className="text-sm font-black text-red-500">- {getCurrencySymbol(getAggregateCurrencyDisplay(monthEntries))} {totalMonthDebit.toLocaleString()}</p>
      </div>
      <div className="flex-1 bg-gray-50 dark:bg-slate-900/50 p-2 rounded-xl border border-gray-100 dark:border-slate-700">
        <p className="text-[9px] font-bold text-gray-400 uppercase">Total Credit</p>
        <p className="text-sm font-black text-emerald-600">+ {getCurrencySymbol(getAggregateCurrencyDisplay(monthEntries))} {totalMonthCredit.toLocaleString()}</p>
      </div>
    </div>
  </div>
</div>

      <div className="grid grid-cols-1 lg:grid-cols-3 md:gap-6 gap-3">
        <div className="lg:col-span-1">
          <CalendarView entries={entries} goals={goals} selectedDate={selectedDate} onSelectDate={onSelectDate} onMonthChange={(m, y) => onSelectDate(`${y}-${m}-01`)} />
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div ref={activitiesSectionRef} className="bg-white dark:bg-slate-800 md:p-6 p-3 pl-2 pr-2 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 relative">
            <div className="flex justify-between items-start">
              <h3 className="inline-flex items-center gap-5 pl-4 pr-4 text-lg font-bold uppercase tracking-tighter mb-6 text-gray-800 dark:text-white">
                <ChartLine className="text-green-500 shrink-0" size={30} />
                <span>
                  <span className="hidden sm:inline">Point </span>Trends of
                  <span className="hidden sm:inline"> {monthName} {selectedYear}</span>
                  <span className="md:hidden md:inline"> {monthNameShort} {String(selectedYear).slice(-2)}</span>
                </span>
              </h3>
              <button onClick={() => setShowLabels(!showLabels)} className="p-2 mr-4 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors text-slate-600 dark:text-slate-300" title={showLabels ? "Hide Goal Names" : "Show Goal Names"}>
                {showLabels ? <Eye size={18} /> : <EyeOff size={18} />}
              </button>
            </div>
            <div onTouchStartCapture={(e) => e.stopPropagation()} onTouchEndCapture={(e) => e.stopPropagation()}>
              <LineGraph data={graphData} monthName={monthName} showGoalNames={showLabels} variant="dashboard" />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 md:p-6 p-0">
            <div className="flex items-center justify-between md:p-0 p-3 pb-0">
              <h3 className="inline-flex items-center md:gap-5 gap-2 text-lg font-bold mb-6 text-gray-800 dark:text-white uppercase tracking-tighter">
                <ScrollText className="text-pink-500 shrink-0" size={30} />
                <span>
                  Activities <span className="hidden sm:inline">for {formattedFullActivitiesDate}</span>
                  <span className="sm:hidden"> {formattedActivitiesDate}</span>
                </span>
              </h3>
              <div className="flex gap-1">
                <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }} onClick={handlePrevDate} className="p-2 rounded-xl bg-gray-50 dark:bg-slate-900 border border-gray-100 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-blue-500 hover:text-white transition-colors shadow-sm">
                  <ChevronLeft size={18} />
                </motion.button>
                <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }} onClick={handleNextDate} className="p-2 rounded-xl bg-gray-50 dark:bg-slate-900 border border-gray-100 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-blue-500 hover:text-white transition-colors shadow-sm">
                  <ChevronRight size={18} />
                </motion.button>
              </div>
            </div>
            <div className="md:space-y-3 space-y-1.5 md:p-0 p-1">
              {selectedDateEntries.length === 0 ? (
                <div className="text-center py-10 text-gray-400 italic">No activities recorded.</div>
              ) : (
                <AnimatePresence initial={false} mode="sync">
                  {selectedDateEntries.map(entry => {
                    const isGoal = goals.some(g => g.code === entry.code && g.achievedAt === entry.toDate);
                    const isCash = !!(entry.debit || entry.credit);
                    return (
                      <motion.div
                        ref={(el) => {
                          activityRefs.current[entry.id] = el;
                        }}
                        key={entry.id}
                        initial={shouldReduceMotion ? false : { opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
                        transition={shouldReduceMotion ? { duration: 0.15 } : { type: 'spring', stiffness: 320, damping: 30, mass: 0.7 }}
                        layout
                        className="group md:p-4 p-3 rounded-2xl border border-gray-100 dark:border-slate-700 bg-gray-50 dark:bg-slate-900/50 hover:bg-white dark:hover:bg-slate-800 transition-colors shadow-sm"
                      >
                        <div className="flex items-start gap-3">
                          <div className={`md:w-12 md:h-12 w-10 h-10 rounded-xl flex items-center justify-center font-black md:text-xs text-[10px] shrink-0 ${isGoal ? 'bg-emerald-600' : 'bg-blue-600'} text-white shadow-lg`}>
                            {entry.code}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-gray-800 dark:text-white truncate">{entry.name}</h4>
                              {isGoal && <Star size={14} className="text-emerald-500" fill="currentColor" />}
                              {isCash && <Banknote size={14} className="text-emerald-500" />}
                            </div>

                            <div className="inline-flex items-center gap-2 mt-1.5 px-2 py-1 rounded-lg border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 text-[10px] font-bold text-gray-500 dark:text-gray-400 shadow-sm">
                              <Clock size={10} />
                              <span>{entry.isLongEvent ? `${entry.fromTime} — ${entry.toTime}` : entry.toTime}</span>
                              {isCash && (
                                <div className="flex gap-2 ml-1 border-l pl-2 border-gray-200 dark:border-slate-700">
                                  {entry.debit > 0 && <span className="text-red-500">-{entry.debit}{getCurrencySymbol(entry.moneyCode)}</span>}
                                  {entry.credit > 0 && <span className="text-emerald-500">+{entry.credit}{getCurrencySymbol(entry.moneyCode)}</span>}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-3 shrink-0">
                            <span className={`text-lg font-black ${isGoal ? 'text-emerald-500' : 'text-blue-600'}`}>
                              +{entry.points}
                            </span>
                            <div className="flex flex-col border-l border-gray-200 dark:border-slate-700 pl-2 gap-1 md:opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={() => onEdit(entry)} className="p-1 text-gray-400 hover:text-blue-500 transition-colors">
                                <Edit2 size={15} />
                              </button>
                              <button onClick={() => onDelete(entry.id)} className="p-1 text-gray-400 hover:text-red-600 transition-colors">
                                <Trash2 size={15} />
                              </button>
                            </div>
                          </div>
                        </div>

                        {entry.description && (
                          <div className={`md:mt-4 mt-2 w-full md:p-3 p-1 pl-3 rounded-xl whitespace-pre-wrap shadow-inner text-xs italic leading-relaxed border-l-4 ${isGoal ? 'bg-emerald-50/50 dark:bg-emerald-900/20 border-emerald-500 text-emerald-700 dark:text-emerald-300' : 'bg-gray-100/50 dark:bg-slate-800/80 border-blue-500 text-gray-600 dark:text-gray-300'}`}>
                            {entry.description}
                          </div>
                        )}

                        {entry.attachment && (
                          <div className="mt-3">
                            <a href={entry.attachment} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-blue-500 dark:text-blue-400 bg-blue-500/5 px-3 py-1.5 rounded-xl hover:bg-blue-500/10 transition-all border border-blue-500/20 shadow-sm">
                              <Paperclip size={12} /> View Attachment
                            </a>
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              )}
            </div>
          </div>
        </div>
      </div>
      <QuickPopData
        isOpen={popDataConfig.isOpen}
        onClose={() => setPopDataConfig(prev => ({ ...prev, isOpen: false }))}
        type={popDataConfig.type}
        entries={entries}
        goals={goals}
        selectedDate={selectedDate}
        onSelectDate={onSelectDate}
        scrollToActivities={() => {
          activitiesSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }}
        scrollToActivity={scrollToActivity}
        userName={userName}
        currentTimeClass={currentTimeClass}
      />
    </div>
  );
};

export default Dashboard;