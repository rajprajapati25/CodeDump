/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Track, EqualizerSetting } from "../types";

export class AudioEngine {
  private audioCtx: AudioContext | null = null;
  private audioElement: HTMLVideoElement | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  
  // Custom EQ Nodes
  private bassFilter: BiquadFilterNode | null = null;
  private midFilter: BiquadFilterNode | null = null;
  private trebleFilter: BiquadFilterNode | null = null;
  
  // Custom Reverb/Metalizer Node
  private metalizerNode: BiquadFilterNode | null = null;
  private delayNode: DelayNode | null = null;
  private metalGainNode: GainNode | null = null;
  
  // Core Visualiser Node
  private analyserNode: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  
  // Generative Synthesizer State
  private synthInterval: number | null = null;
  private activeSynthNodes: AudioNode[] = [];
  
  // Engine callbacks
  private onTimeUpdateCallback: ((time: number) => void) | null = null;
  private onDurationChangeCallback: ((duration: number) => void) | null = null;
  private onTrackEndedCallback: (() => void) | null = null;
  private onSynthNoteCallback: ((note: string, freq: number) => void) | null = null;
  
  // Tracking playback details
  private isPlayingGenerative = false;
  private generativeStartTime = 0;
  private generativeElapsedTime = 0;
  private currentGenerativeType: "chime" | "drone" | "beat" | "sparkle" = "chime";
  
  constructor() {
    // Audio elements will be initialized upon user gesture
  }

  public init() {
    if (this.audioCtx) return;

    try {
      // Initialize Context
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // We use an HTMLVideoElement dynamically. It works for audio and video media playing.
      this.audioElement = document.createElement("video");
      this.audioElement.crossOrigin = "anonymous";
      this.audioElement.playsInline = true;
      this.audioElement.setAttribute("playsinline", "true");
      this.audioElement.setAttribute("webkit-playsinline", "true");
      
      // Hook up timeupdates
      this.audioElement.addEventListener("timeupdate", () => {
        if (!this.isPlayingGenerative && this.onTimeUpdateCallback && this.audioElement) {
          this.onTimeUpdateCallback(this.audioElement.currentTime);
        }
      });

      this.audioElement.addEventListener("durationchange", () => {
        if (!this.isPlayingGenerative && this.audioElement && this.onDurationChangeCallback) {
          this.onDurationChangeCallback(this.audioElement.duration || 0);
        }
      });

      this.audioElement.addEventListener("ended", () => {
        if (!this.isPlayingGenerative && this.onTrackEndedCallback) {
          this.onTrackEndedCallback();
        }
      });

      // Build web audio graph nodes
      this.sourceNode = this.audioCtx.createMediaElementSource(this.audioElement);
      
      this.bassFilter = this.audioCtx.createBiquadFilter();
      this.bassFilter.type = "lowshelf";
      this.bassFilter.frequency.value = 150; // Bass threshold

      this.midFilter = this.audioCtx.createBiquadFilter();
      this.midFilter.type = "peaking";
      this.midFilter.Q.value = 1.0;
      this.midFilter.frequency.value = 1000; // Vocal/Midband

      this.trebleFilter = this.audioCtx.createBiquadFilter();
      this.trebleFilter.type = "highshelf";
      this.trebleFilter.frequency.value = 6000; // Treble threshold

      // Metalizer feedback loop structure
      this.delayNode = this.audioCtx.createDelay();
      this.delayNode.delayTime.value = 0.025; // short delay for metallic comb-comb vibe

      this.metalizerNode = this.audioCtx.createBiquadFilter();
      this.metalizerNode.type = "peaking";
      this.metalizerNode.Q.value = 12.0; // ultra high-resonance
      this.metalizerNode.frequency.value = 1800; // specific metallic peak

      this.metalGainNode = this.audioCtx.createGain();
      this.metalGainNode.gain.value = 0.0; // dry by default

      // Connect metalizer loops
      this.delayNode.connect(this.metalizerNode);
      this.metalizerNode.connect(this.metalGainNode);

      // Core analyser
      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 512;

      // Master output volume gain
      this.gainNode = this.audioCtx.createGain();
      this.gainNode.gain.value = 0.8;

      // Connect source to filters
      this.sourceNode.connect(this.bassFilter);
      this.bassFilter.connect(this.midFilter);
      this.midFilter.connect(this.trebleFilter);
      
      // Parallel routing for Metalizer loop
      this.trebleFilter.connect(this.analyserNode);
      this.trebleFilter.connect(this.delayNode);
      this.metalGainNode.connect(this.analyserNode);

      // Connect Analyser to Gain and then Output Destination
      this.analyserNode.connect(this.gainNode);
      this.gainNode.connect(this.audioCtx.destination);

    } catch (e) {
      console.error("Web Audio API not supported / initialized:", e);
    }
  }

  // Set up callbacks
  public setOnTimeUpdate(cb: (time: number) => void) {
    this.onTimeUpdateCallback = cb;
  }

  public setOnDurationChange(cb: (duration: number) => void) {
    this.onDurationChangeCallback = cb;
  }

  public setOnTrackEnded(cb: () => void) {
    this.onTrackEndedCallback = cb;
  }

  public setOnSynthNote(cb: (note: string, freq: number) => void) {
    this.onSynthNoteCallback = cb;
  }

  public getMediaElement(): HTMLVideoElement | null {
    return this.audioElement;
  }

  // Master Audio Volume
  public setVolume(val: number) {
    this.init();
    if (this.gainNode) {
      // Bound volume between 0 and 1
      this.gainNode.gain.setValueAtTime(Math.max(0, Math.min(1, val)), this.audioCtx!.currentTime);
    }
  }

  // Apply Equalizer Bands (Bass, Mid, Treble)
  public applyEqualizer(eq: EqualizerSetting) {
    this.init();
    if (this.bassFilter) this.bassFilter.gain.setValueAtTime(eq.bass, this.audioCtx!.currentTime);
    if (this.midFilter) this.midFilter.gain.setValueAtTime(eq.mid, this.audioCtx!.currentTime);
    if (this.trebleFilter) this.trebleFilter.gain.setValueAtTime(eq.treble, this.audioCtx!.currentTime);
  }

  // Toggle or slide "Metalizer Reverb Effect"
  public setMetalizerLevel(level: number) {
    this.init();
    if (this.metalGainNode && this.delayNode && this.metalizerNode) {
      // level between 0 and 1
      const normalizedLevel = Math.max(0, Math.min(1, level));
      this.metalGainNode.gain.setValueAtTime(normalizedLevel * 0.75, this.audioCtx!.currentTime);
      
      // Modulate delay time and filter freq slightly depending on metalizer level for coolness
      this.delayNode.delayTime.setValueAtTime(0.015 + (normalizedLevel * 0.035), this.audioCtx!.currentTime);
      this.metalizerNode.frequency.setValueAtTime(1400 + (normalizedLevel * 1200), this.audioCtx!.currentTime);
    }
  }

  // Load a standard streaming or local track
  public loadTrack(track: Track) {
    this.init();
    this.stopGenerativeSynth();

    if (track.isGenerative) {
      this.isPlayingGenerative = true;
      this.currentGenerativeType = track.generativeType || "chime";
      this.generativeElapsedTime = 0;
      this.generativeStartTime = Date.now();
      
      if (this.audioElement) {
        this.audioElement.pause();
        this.audioElement.src = "";
      }
      return;
    }

    this.isPlayingGenerative = false;
    if (this.audioElement && track.url) {
      try {
        this.audioElement.src = track.url;
        this.audioElement.load();
      } catch (err) {
        console.error("Error setting audio src: ", err);
      }
    }
  }

  // Play/Pause controlling
  public async play() {
    this.init();
    if (this.audioCtx?.state === "suspended") {
      await this.audioCtx.resume();
    }

    if (this.isPlayingGenerative) {
      this.startGenerativeSynth();
    } else if (this.audioElement) {
      try {
        await this.audioElement.play();
      } catch (e) {
        console.warn("Autoplay block / playback error: ", e);
      }
    }
  }

  public pause() {
    if (this.isPlayingGenerative) {
      this.pauseGenerativeSynth();
    } else if (this.audioElement) {
      this.audioElement.pause();
    }
  }

  public seek(seconds: number) {
    if (this.isPlayingGenerative) {
      this.generativeElapsedTime = Math.max(0, Math.min(600, seconds)); // Keep generative play within limits
    } else if (this.audioElement) {
      this.audioElement.currentTime = seconds;
    }
  }

  public setPlaybackRate(rate: number) {
    if (this.audioElement) {
      this.audioElement.playbackRate = rate;
    }
  }

  // Retrieve current playtime
  public getCurrentTime(): number {
    if (this.isPlayingGenerative) {
      return this.generativeElapsedTime;
    }
    return this.audioElement ? this.audioElement.currentTime : 0;
  }

  // Real-time dynamic analyser values for canvas rendering
  public getAnalyserData() {
    if (!this.analyserNode) {
      return { freqData: new Uint8Array(0), waveData: new Uint8Array(0) };
    }
    const bufferLength = this.analyserNode.frequencyBinCount;
    const freqData = new Uint8Array(bufferLength);
    const waveData = new Uint8Array(bufferLength);
    
    this.analyserNode.getByteFrequencyData(freqData);
    this.analyserNode.getByteTimeDomainData(waveData);
    
    return { freqData, waveData };
  }

  // ==========================================
  // PROCEDURAL SILVER GENERATIVE SYNTH ENGINE
  // ==========================================

  private startGenerativeSynth() {
    if (this.synthInterval) return;
    this.init();

    // Reconnect audio output to active context
    if (this.audioCtx?.state === "suspended") {
      this.audioCtx.resume();
    }

    const noteFrequencies: { [key: string]: number } = {
      C4: 261.63, D4: 293.66, E4: 329.63, G4: 392.00, A4: 440.00,
      C5: 523.25, D5: 587.33, E5: 659.25, G5: 783.99, A5: 880.00,
      C6: 1046.50
    };
    const notes = Object.keys(noteFrequencies);

    let tick = 0;
    const tickTime = 250; // ms per tick

    // Start timer for generative stats
    const timerStart = Date.now() - (this.generativeElapsedTime * 1000);
    
    this.synthInterval = window.setInterval(() => {
      if (!this.audioCtx) return;
      
      // Update running play time
      this.generativeElapsedTime = (Date.now() - timerStart) / 1000;
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.generativeElapsedTime);
      }

      // Check ended condition (automatic endless loop or restart after 10 mins)
      if (this.generativeElapsedTime >= 600) {
        this.generativeElapsedTime = 0;
      }

      tick++;

      // Trigger specific synthesizer sounds based on selected genre/type
      if (this.currentGenerativeType === "chime") {
        // Sparkling pentatonic metallic chimes
        if (tick % 3 === 0 || Math.random() > 0.7) {
          const randomNote = notes[Math.floor(Math.random() * notes.length)];
          const freq = noteFrequencies[randomNote];
          this.triggerChime(freq, 1.2);
          if (this.onSynthNoteCallback) this.onSynthNoteCallback(randomNote, freq);
        }
        
        // Deep background drone Sweep
        if (tick % 16 === 1) {
          this.triggerSweepDrone(130.81, 4.0); // low C
        }
      } 
      
      else if (this.currentGenerativeType === "drone") {
        // Deep space gallium hum
        if (tick % 24 === 1) {
          this.triggerSweepDrone(110.00, 6.0); // A2 drone
          this.triggerSweepDrone(165.00, 5.5); // E3 drone
        }
        if (tick % 4 === 0 && Math.random() > 0.5) {
          const softNotes = ["A4", "E5", "A5", "C6"];
          const note = softNotes[Math.floor(Math.random() * softNotes.length)];
          this.triggerChime(noteFrequencies[note], 2.5, 0.05); // high airy bells
        }
      } 
      
      else if (this.currentGenerativeType === "beat") {
        // Generative electronic metallic beat
        const subTick = tick % 8;
        
        // Kick on 1 and 5
        if (subTick === 0 || subTick === 4) {
          this.triggerDrumKick();
        }
        
        // Snare/Noise on 3 and 7
        if (subTick === 2 || subTick === 6) {
          this.triggerDrumSnare();
        }
        
        // Hihat on offset ticks
        if (subTick % 2 === 1) {
          this.triggerDrumHihat();
        }

        // Sparkling synth lead track
        if (subTick % 2 === 0 && Math.random() > 0.4) {
          const leadNotes = ["C4", "E4", "G4", "A4", "C5", "E5"];
          const note = leadNotes[Math.floor(Math.random() * leadNotes.length)];
          this.triggerPluckLead(noteFrequencies[note]);
        }
      } 
      
      else if (this.currentGenerativeType === "sparkle") {
        // Hyper sparkling digital silver stardust
        if (Math.random() > 0.3) {
          const highNotes = ["G5", "A5", "C6", "D6", "E6", "G6"];
          const note = highNotes[Math.floor(Math.random() * highNotes.length)];
          const f = noteFrequencies[note] || 1500;
          this.triggerHighSparkle(f);
        }
      }

    }, tickTime);
  }

  // Synthesize Bell/Chime
  private triggerChime(freq: number, duration: number, volume = 0.25) {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, now);
    
    // Add chime ring modulation: multiply with second metallic harmonic
    const ringOsc = this.audioCtx.createOscillator();
    ringOsc.type = "triangle";
    ringOsc.frequency.setValueAtTime(freq * 1.5, now);
    
    const ringGain = this.audioCtx.createGain();
    ringGain.gain.setValueAtTime(0.08, now);

    // Fade envelope
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    // Route connections
    ringOsc.connect(ringGain);
    ringGain.connect(osc.frequency); // frequency modulation!
    
    osc.connect(gain);
    gain.connect(this.analyserNode);

    osc.start(now);
    ringOsc.start(now);
    osc.stop(now + duration + 0.1);
    ringOsc.stop(now + duration + 0.1);

    this.activeSynthNodes.push(osc, ringOsc, gain, ringGain);
  }

  // Synthesize Pluck Lead
  private triggerPluckLead(freq: number) {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    const osc1 = this.audioCtx.createOscillator();
    const osc2 = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc1.type = "sawtooth";
    osc1.frequency.setValueAtTime(freq, now);
    
    osc2.type = "triangle";
    osc2.frequency.setValueAtTime(freq * 1.01, now); // Detune slightly

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.analyserNode);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.5);
    osc2.stop(now + 0.5);

    this.activeSynthNodes.push(osc1, osc2, gain);
  }

  // Synthesize High Shimmer Sparkles
  private triggerHighSparkle(freq: number) {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    const osc = this.audioCtx.createOscillator();
    const filter = this.audioCtx.createBiquadFilter();
    const gain = this.audioCtx.createGain();

    osc.type = "triangle";
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 1.8, now + 0.12); // Sweeping sparkle

    filter.type = "highpass";
    filter.frequency.setValueAtTime(3000, now);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.1, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.analyserNode);

    osc.start(now);
    osc.stop(now + 0.3);

    this.activeSynthNodes.push(osc, filter, gain);
  }

  // Synthesize Deep Swooping Ambient Drone
  private triggerSweepDrone(freq: number, duration: number) {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    const osc1 = this.audioCtx.createOscillator();
    const osc2 = this.audioCtx.createOscillator();
    const filter = this.audioCtx.createBiquadFilter();
    const gain = this.audioCtx.createGain();

    osc1.type = "sawtooth";
    osc1.frequency.setValueAtTime(freq, now);

    osc2.type = "triangle";
    osc2.frequency.setValueAtTime(freq * 1.02, now); // Detuned harmonic

    filter.type = "lowpass";
    filter.frequency.setValueAtTime(100, now);
    filter.frequency.exponentialRampToValueAtTime(450, now + (duration / 2));
    filter.frequency.exponentialRampToValueAtTime(80, now + duration);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.18, now + (duration * 0.2));
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(this.analyserNode);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + duration + 0.2);
    osc2.stop(now + duration + 0.2);

    this.activeSynthNodes.push(osc1, osc2, filter, gain);
  }

  // Synthesize Acoustic drum elements (Kick, Snare, Hihat)
  private triggerDrumKick() {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(0.01, now + 0.15); // Quick sweep for kick slap

    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);

    osc.connect(gain);
    gain.connect(this.analyserNode);

    osc.start(now);
    osc.stop(now + 0.2);

    this.activeSynthNodes.push(osc, gain);
  }

  private triggerDrumSnare() {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    // Buffer creation for white noise
    const bufferSize = this.audioCtx.sampleRate * 0.18; // short snare noise
    const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noiseNode = this.audioCtx.createBufferSource();
    noiseNode.buffer = buffer;

    const filter = this.audioCtx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(1000, now);

    const gain = this.audioCtx.createGain();
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);

    // Connect noise snare
    noiseNode.connect(filter);
    filter.connect(gain);
    gain.connect(this.analyserNode);

    // Combine with a small sine wave snap
    const osc = this.audioCtx.createOscillator();
    const snapGain = this.audioCtx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(180, now);
    snapGain.gain.setValueAtTime(0.15, now);
    snapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

    osc.connect(snapGain);
    snapGain.connect(this.analyserNode);

    noiseNode.start(now);
    osc.start(now);
    
    noiseNode.stop(now + 0.2);
    osc.stop(now + 0.2);

    this.activeSynthNodes.push(noiseNode, filter, gain, osc, snapGain);
  }

  private triggerDrumHihat() {
    if (!this.audioCtx || !this.analyserNode) return;
    const now = this.audioCtx.currentTime;

    const bufferSize = this.audioCtx.sampleRate * 0.04; // ultra short hihat
    const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noiseNode = this.audioCtx.createBufferSource();
    noiseNode.buffer = buffer;

    const filter = this.audioCtx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.setValueAtTime(8000, now);

    const gain = this.audioCtx.createGain();
    gain.gain.setValueAtTime(0.05, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.03);

    noiseNode.connect(filter);
    filter.connect(gain);
    gain.connect(this.analyserNode);

    noiseNode.start(now);
    noiseNode.stop(now + 0.05);

    this.activeSynthNodes.push(noiseNode, filter, gain);
  }

  private pauseGenerativeSynth() {
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }

  private stopGenerativeSynth() {
    this.pauseGenerativeSynth();
    // Stop and disconnect any nodes
    this.activeSynthNodes.forEach(node => {
      try {
        (node as any).stop();
      } catch (e) {}
      try {
        node.disconnect();
      } catch (e) {}
    });
    this.activeSynthNodes = [];
  }
}

// Single active static reference
export const globalAudioEngine = new AudioEngine();
