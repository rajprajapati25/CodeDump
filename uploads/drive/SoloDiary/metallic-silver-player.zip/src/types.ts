/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Track {
  id: string;
  title: string;
  artist: string;
  duration: number; // in seconds
  url?: string;     // URL if external stream, undefined for generative synthesized tracks
  genre: string;
  coverImage?: string; // Optional cover color/imagery
  isGenerative?: boolean;
  generativeType?: "chime" | "drone" | "beat" | "sparkle";
  userUploaded?: boolean;
  isVideo?: boolean;
}

export type EQPreset = "flat" | "bass" | "vocals" | "electronic" | "metalizer";

export interface EqualizerSetting {
  bass: number; // -12 to 12 dB
  mid: number;  // -12 to 12 dB
  treble: number; // -12 to 12 dB
}

export type VisualizerMode = "liquid" | "bars" | "spectrum" | "circular" | "wave";

export interface PlayerStats {
  samplingRate: number;
  channels: number;
  byteLatency: number;
  noiseLevel: number;
}
