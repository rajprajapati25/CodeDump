/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from "react";
import { Track } from "../types";
import { Upload, Music, Disc, Trash2, Heart, FolderOpen } from "lucide-react";

interface PlaylistsViewProps {
  tracks: Track[];
  onSelectTrack: (track: Track) => void;
  currentTrack: Track;
  onUploadTrack: (file: File) => void;
  onRemoveTrack?: (id: string) => void;
}

export default function PlaylistsView({
  tracks,
  onSelectTrack,
  currentTrack,
  onUploadTrack,
  onRemoveTrack,
}: PlaylistsViewProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("silver_player_favorites");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith("audio/") || file.type.startsWith("video/") || file.name.endsWith(".mp4")) {
        onUploadTrack(file);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadTrack(e.target.files[0]);
    }
  };

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated: string[];
    if (favorites.includes(id)) {
      updated = favorites.filter(favId => favId !== id);
    } else {
      updated = [...favorites, id];
    }
    setFavorites(updated);
    try {
      localStorage.setItem("silver_player_favorites", JSON.stringify(updated));
    } catch (err) {
      console.warn("Storage write failed", err);
    }
  };

  // Human-readable minutes/seconds
  const formatSecs = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = Math.floor(totalSecs % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  return (
    <div className="flex flex-col gap-4 text-slate-300" id="playlist-panels">
      {/* File Dropping Section */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        id="uploader-container"
        className={`border border-dashed rounded-xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all duration-200 text-center ${
          isDragOver
            ? "border-white bg-white/10 text-white scale-[0.99]"
            : "border-slate-700 hover:border-slate-400 hover:bg-white/5 text-slate-400"
        }`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="audio/*,video/mp4,video/*"
          className="hidden"
          id="audio-uploader-input"
        />
        <div className="relative">
          <Upload size={20} className={`${isDragOver ? "animate-bounce text-white" : "text-slate-500"}`} />
          <FolderOpen size={10} className="absolute -bottom-1 -right-1 text-slate-400" />
        </div>
        <div>
          <p className="text-xs font-semibold">Drag & Drop Audio or MP4 Video</p>
          <p className="text-[10px] text-slate-500 mt-0.5">Loads local MP3, WAV, AAC, or MP4 directly</p>
        </div>
      </div>

      {/* Playlist Grid Scroll */}
      <div className="flex flex-col gap-1.5" id="tracks-scroll-list">
        <div className="flex items-center justify-between px-1 text-xs text-slate-400 font-mono tracking-wider uppercase mb-1">
          <span>Tracks Playlist</span>
          <span className="text-[10px] text-slate-500">{tracks.length} Loaded</span>
        </div>

        <div className="max-h-72 overflow-y-auto pr-1 flex flex-col gap-1" id="tracks-inner-list">
          {tracks.map((track) => {
            const isPlayingThis = track.id === currentTrack.id;
            const isFav = favorites.includes(track.id);

            return (
              <div
                key={track.id}
                onClick={() => onSelectTrack(track)}
                id={`track-${track.id}`}
                className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer border transition-all duration-150 ${
                  isPlayingThis
                    ? "bg-white/12 border-white/20 text-white shadow-md shadow-black/30"
                    : "bg-black/20 border-transparent hover:bg-white/5 hover:border-white/5 text-slate-300"
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Rotating CD or standard icon */}
                  <div className="relative shrink-0">
                    <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-white/10">
                      {isPlayingThis ? (
                        <Disc size={13} className="text-white animate-spin [animation-duration:4s]" />
                      ) : (
                        <Music size={13} className="text-slate-500" />
                      )}
                    </div>
                  </div>

                  {/* Text descriptions */}
                  <div className="min-w-0 pr-1">
                    <p className={`text-xs font-medium truncate ${isPlayingThis ? "text-slate-100" : "text-slate-300"}`}>
                      {track.title}
                    </p>
                    <p className="text-[10px] text-slate-500 truncate mt-0.5 flex items-center gap-1">
                      <span>{track.artist}</span>
                      {track.isGenerative && (
                        <span className="text-[8px] tracking-wider uppercase bg-white/5 text-slate-400 px-1 py-0.5 rounded border border-white/5 shrink-0 scale-90">
                          GEN
                        </span>
                      )}
                      {track.userUploaded && (
                        <span className="text-[8px] tracking-wider uppercase bg-slate-900 border border-slate-700 text-slate-400 px-1 py-0.5 rounded shrink-0 scale-90">
                          USER
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                {/* Right utility buttons */}
                <div className="flex items-center gap-1.5 opacity-80 group-hover:opacity-100">
                  <button
                    onClick={(e) => toggleFavorite(track.id, e)}
                    id={`fav-${track.id}`}
                    className="p-1 hover:text-white transition-colors"
                    title={isFav ? "Remove Favorite" : "Favorite"}
                  >
                    <Heart
                      size={12}
                      className={isFav ? "text-red-400 fill-red-400 scale-110" : "text-slate-500 hover:text-slate-300"}
                    />
                  </button>

                  <span className="text-[10px] font-mono text-slate-500 group-hover:text-slate-400 pr-1.5 select-none">
                    {formatSecs(track.duration)}
                  </span>

                  {/* Remove custom upload button */}
                  {track.userUploaded && onRemoveTrack && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveTrack(track.id);
                      }}
                      id={`delete-${track.id}`}
                      className="p-1 hover:text-red-400 text-slate-600 transition-colors shrink-0"
                      title="Delete Track"
                    >
                      <Trash2 size={12} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
