/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from "react";
import { Track, VisualizerMode } from "../types";
import AudioVisualizer from "./AudioVisualizer";
import { Disc, Play, Pause, Camera, SkipBack, SkipForward } from "lucide-react";
import { globalAudioEngine } from "../utils/AudioEngine";

interface MetallicPlayerCardProps {
  currentTrack: Track;
  isPlaying: boolean;
  onPlayPause: () => void;
  visualizerMode: VisualizerMode;
  currentTime: number;
  onSeek: (secs: number) => void;
  onUpdateTitle: (id: string, newTitle: string) => void;
  onUpdateCoverImage: (id: string, newCoverUrl: string) => void;
  onNext: () => void;
  onPrev: () => void;
  showVisualizer?: boolean;
}

export default function MetallicPlayerCard({
  currentTrack,
  isPlaying,
  onPlayPause,
  visualizerMode,
  currentTime,
  onSeek,
  onUpdateTitle,
  onUpdateCoverImage,
  onNext,
  onPrev,
  showVisualizer = true,
}: MetallicPlayerCardProps) {
  const [showImageEditor, setShowImageEditor] = useState(false);
  const [imageUrlInput, setImageUrlInput] = useState(currentTrack.coverImage || "");
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [scrubValue, setScrubValue] = useState(0);

  const videoContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // If it's a video track, mount the unified HTMLVideoElement inside our artwork bubble!
    const videoEl = globalAudioEngine.getMediaElement();
    const container = videoContainerRef.current;
    if (videoEl && container && currentTrack.isVideo) {
      videoEl.style.width = "-webkit-fill-available";
      videoEl.style.height = "-webkit-fill-available";
      videoEl.style.objectFit = "cover";
      videoEl.style.display = "block";
      videoEl.style.borderRadius = "inherit";
      
      container.innerHTML = "";
      container.appendChild(videoEl);
      
      return () => {
        if (videoEl.parentNode === container) {
          container.removeChild(videoEl);
        }
        videoEl.style.display = "none";
      };
    }
  }, [currentTrack.id, currentTrack.isVideo, isPlaying]);

  const displayTime = isScrubbing ? scrubValue : currentTime;
  const pct = currentTrack.duration > 0 ? (displayTime / currentTrack.duration) * 100 : 0;

  // Formatting seconds to MM:SS format
  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds)) return "0:00";
    const mins = Math.floor(timeInSeconds / 60);
    const secs = Math.floor(timeInSeconds % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  return (
    <>
      {/* Absolute floating displacement SVG filters for fluid mercury borders */}
      <svg className="svg-container">
        <defs>
          <filter id="turbulent-displace" colorInterpolationFilters="sRGB" x="-20%" y="-20%" width="140%" height="140%">
            <feTurbulence type="turbulence" baseFrequency="0.02" numOctaves="8" result="noise1" seed="1" />
            <feOffset in="noise1" dx="0" dy="0" result="offsetNoise1">
              <animate attributeName="dy" values="700; 0" dur="4s" repeatCount="indefinite" calcMode="linear" />
            </feOffset>

            <feTurbulence type="turbulence" baseFrequency="0.02" numOctaves="8" result="noise2" seed="1" />
            <feOffset in="noise2" dx="0" dy="0" result="offsetNoise2">
              <animate attributeName="dy" values="0; -700" dur="4s" repeatCount="indefinite" calcMode="linear" />
            </feOffset>

            <feTurbulence type="turbulence" baseFrequency="0.02" numOctaves="8" result="noise1" seed="2" />
            <feOffset in="noise1" dx="0" dy="0" result="offsetNoise3">
              <animate attributeName="dx" values="490; 0" dur="4s" repeatCount="indefinite" calcMode="linear" />
            </feOffset>

            <feTurbulence type="turbulence" baseFrequency="0.02" numOctaves="8" result="noise2" seed="2" />
            <feOffset in="noise2" dx="0" dy="0" result="offsetNoise4">
              <animate attributeName="dx" values="0; -490" dur="4s" repeatCount="indefinite" calcMode="linear" />
            </feOffset>

            <feComposite in="offsetNoise1" in2="offsetNoise2" result="part1" />
            <feComposite in="offsetNoise3" in2="offsetNoise4" result="part2" />
            <feBlend in="part1" in2="part2" mode="color-dodge" result="combinedNoise" />

            <feDisplacementMap
              in="SourceGraphic"
              in2="combinedNoise"
              scale="22"
              xChannelSelector="R"
              yChannelSelector="B"
            />
          </filter>
        </defs>
      </svg>

      <div className="card-container scale-[0.98] sm:scale-100 transition-transform duration-300 min-h-[550px] h-[650px] flex flex-col justify-between">
        <div className="inner-container">
          <div className="border-outer">
            <div 
              id="displacing-silver-card"
              className={`main-card ${isPlaying ? "main-card-active" : ""}`}
            />
          </div>
          <div className="glow-layer-1"></div>
          <div className="glow-layer-2"></div>
        </div>

        <div className="overlay-1"></div>
        <div className="overlay-2"></div>
        <div className="background-glow"></div>

        {/* Content Container positioned above filter warp */}
        <div className="content-container select-none h-full flex flex-col justify-between items-stretch p-5">
          
          {/* Header Area */}
          <div className="content-top w-full z-10 shrink-0">
            <div className="flex flex-col gap-0.5 relative group/title w-full">
              <input
                type="text"
                value={currentTrack.title}
                onChange={(e) => onUpdateTitle(currentTrack.id, e.target.value)}
                className="title bg-transparent text-slate-100 font-semibold focus:outline-none focus:border-b border-white/20 px-0.5 py-1 text-2xl w-full select-text"
                id="playing-title-input"
                placeholder="Rename Track..."
                title="Click to rename this track"
              />
            </div>
          </div>

          {/* Core Dynamic Stage (Spans all space between title and footer) */}
          <div className="flex-1 my-4 flex flex-col justify-center items-center relative w-full min-h-0 overflow-hidden" id="visualizer-stage-core">
            <div className="absolute inset-0 z-0 bg-radial-gradient from-slate-400/5 to-transparent blur-xl pointer-events-none" />
            
            {/* Music Album Artwork / Video Box - Stretches perfectly based on visualizer status */}
            <div className="relative flex-1 w-full h-full min-h-0 group/cover border-2 border-white/10 rounded-2xl overflow-hidden shadow-xl bg-black/50 flex items-center justify-center z-10 transition-all duration-300 hover:border-white/30 hover:shadow-2xl">
              {currentTrack.isVideo ? (
                <div 
                  ref={videoContainerRef} 
                  className="w-full h-full rounded-2xl overflow-hidden bg-black object-cover"
                  style={{ width: "-webkit-fill-available", height: "-webkit-fill-available" }}
                />
              ) : currentTrack.coverImage ? (
                <img
                  src={currentTrack.coverImage}
                  alt={currentTrack.title}
                  className={`w-full h-full object-cover transition-transform duration-[12s] ease-in-out ${isPlaying ? "scale-110 rotate-[2deg]" : "scale-100"}`}
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-tr from-slate-800 to-slate-950 flex flex-col items-center justify-center text-slate-400 p-4 text-center select-none">
                  <Disc className={`text-slate-500 w-1/4 h-1/4 max-w-[80px] max-h-[80px] hover:text-slate-300 transition-colors ${isPlaying ? "animate-spin" : ""}`} style={{ animationDuration: "6s" }} />
                  <span className="text-[10px] font-mono mt-3 uppercase tracking-wide text-slate-500">No Cover Art</span>
                </div>
              )}

              {/* Edit Cover Overlay on hover */}
              <button
                onClick={() => setShowImageEditor(!showImageEditor)}
                className="absolute inset-0 bg-black/75 opacity-0 group-hover/cover:opacity-100 flex flex-col items-center justify-center gap-1.5 text-xs text-white transition-opacity font-mono font-medium text-[9px] uppercase tracking-wider cursor-pointer z-20"
                style={{ width: "-webkit-fill-available", height: "-webkit-fill-available" }}
                title="Manually Set Album Cover Image"
              >
                <Camera size={18} className="text-white animate-pulse" />
                <span>Adjust Art</span>
              </button>
            </div>

            {/* Overlaid Waveform lines (Conditionally renders and frees space if hidden) */}
            {showVisualizer && (
              <div className="w-full h-20 relative z-20 flex items-center justify-center pointer-events-none mt-3 shrink-0" id="mini-viz-contain">
                <AudioVisualizer mode={visualizerMode} isActive={isPlaying} />
              </div>
            )}

            {/* Photo Image Selector popover tray */}
            {showImageEditor && (
              <div id="image-art-work" className="absolute top-[5%] left-4 right-4 p-4 rounded-xl bg-zinc-950/95 border border-white/15 shadow-2xl z-40 flex flex-col gap-2.5 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono tracking-wider text-slate-400 uppercase font-bold">🛠️ Album Artwork Source</span>
                  <button 
                    onClick={() => setShowImageEditor(false)} 
                    className="text-slate-500 hover:text-white text-[10px] px-1 font-mono tracking-widest hover:scale-105 cursor-pointer"
                  >
                    [CLOSE]
                  </button>
                </div>

                {/* Cover art form */}
                <div className="flex flex-col gap-2 text-xs">
                  <div>
                    <label className="text-[9px] font-mono text-zinc-500 block mb-1 uppercase tracking-wider">Image Address (URL)</label>
                    <input
                      type="text"
                      value={imageUrlInput}
                      onChange={(e) => {
                        setImageUrlInput(e.target.value);
                        onUpdateCoverImage(currentTrack.id, e.target.value);
                      }}
                      placeholder="Paste image URL (e.g. Unsplash, Picsum)..."
                      className="w-full bg-white/5 border border-white/10 rounded px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-white/30 font-mono select-text"
                    />
                  </div>

                  <div className="text-center text-[10px] text-zinc-600 font-mono my-0.5">— OR —</div>

                  <div>
                    <label className="text-[9px] font-mono text-zinc-500 block mb-1 uppercase tracking-wider">Upload local cover photo</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          const file = e.target.files[0];
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            if (event.target?.result) {
                              onUpdateCoverImage(currentTrack.id, event.target.result as string);
                              setImageUrlInput("");
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="w-full text-[11px] text-slate-400 file:mr-3 file:py-1 file:px-2.5 file:rounded file:border-0 file:text-[9px] file:font-mono file:bg-white/10 file:text-white file:cursor-pointer hover:file:bg-white/12"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Glowing disc watermark behind active wave */}
            <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-[0.02] select-none pointer-events-none">
              <Disc size={180} className={`${isPlaying ? "animate-spin" : ""}`} style={{ animationDuration: "12s" }} />
            </div>
          </div>

          {/* Consolidated Bottom Controls Area (Always Locked to Bottom) */}
          <div id="bottom-controler-button" className="w-full flex flex-col gap-2 mt-auto z-10 shrink-0">
            
            {/* Progressive Scrubber Slider Area */}
            <div className="px-1 flex flex-col gap-1 text-slate-300" id="scrubber-deck">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>{formatTime(displayTime)}</span>
                <span>{formatTime(currentTrack.duration)}</span>
              </div>
              
              <div className="group relative w-full flex items-center h-4 cursor-pointer" id="progress-container">
                {/* Progress track background */}
                <div className="w-full h-1 bg-white/5 rounded-full absolute" />
                {/* Active track filling */}
                <div 
                  className="h-1 bg-gradient-to-r from-slate-300 to-white rounded-full absolute shadow-[0_0_8px_rgba(255,255,255,0.7)] transition-all"
                  style={{ width: `${pct}%` }}
                />
                <input
                  type="range"
                  min="0"
                  max={currentTrack.duration}
                  step="0.1"
                  value={displayTime}
                  onMouseDown={() => {
                    setIsScrubbing(true);
                    setScrubValue(currentTime);
                  }}
                  onTouchStart={() => {
                    setIsScrubbing(true);
                    setScrubValue(currentTime);
                  }}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setScrubValue(val);
                    onSeek(val);
                  }}
                  onMouseUp={() => {
                    setIsScrubbing(false);
                  }}
                  onTouchEnd={() => {
                    setIsScrubbing(false);
                  }}
                  id="progress-scrubber"
                  className="w-full h-4 opacity-0 absolute cursor-pointer z-10"
                />
                <div 
                  className="w-3 h-3 bg-white border-2 border-slate-900 rounded-full absolute -ml-1.5 shadow-md shadow-black/80 scale-0 group-hover:scale-100 transition-transform duration-100 pointer-events-none"
                  style={{ left: `${pct}%` }}
                />
              </div>
            </div>

            <hr className="divider opacity-20 my-1" />

            {/* Footer Deck Controls */}
            <div className="content-bottom py-1" id="footer-actions-deck">
              <div id="footer-actions-deck-two" className="flex items-center justify-between bg-black/40 px-3.5 py-2.5 rounded-xl border border-white/5 shadow-inner w-full gap-2">
                <button
                  onClick={onPrev}
                  id="footer-prev-btn"
                  className="py-1.5 px-3 rounded-lg text-slate-400 hover:text-white transition-all active:scale-90 flex items-center gap-1.5 hover:bg-white/5 cursor-pointer"
                  title="Previous Track"
                >
                  <SkipBack size={15} />
                  <span className="text-[10px] font-mono uppercase tracking-widest hidden sm:inline">Prev</span>
                </button>

                <button
                  onClick={onPlayPause}
                  id="footer-play-btn"
                  className="w-10 h-10 rounded-full bg-slate-100 text-black hover:bg-white flex items-center justify-center cursor-pointer shadow-lg hover:gradient-silver-scale active:scale-95 transition-all"
                  title={isPlaying ? "Pause" : "Play"}
                >
                  {isPlaying ? <Pause size={14} fill="black" /> : <Play size={14} fill="black" className="ml-0.5" />}
                </button>

                <button
                  onClick={onNext}
                  id="footer-next-btn"
                  className="py-1.5 px-3 rounded-lg text-slate-400 hover:text-white transition-all active:scale-90 flex items-center gap-1.5 hover:bg-white/5 cursor-pointer"
                  title="Next Track"
                >
                  <span className="text-[10px] font-mono uppercase tracking-widest hidden sm:inline">Next</span>
                  <SkipForward size={15} />
                </button>
              </div>
            </div>

          </div> {/* End Consolidated Bottom Area */}

        </div>
        
      </div>
    </>
  );
}