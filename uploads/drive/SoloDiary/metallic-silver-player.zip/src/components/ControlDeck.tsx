/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EQPreset, EqualizerSetting, VisualizerMode } from "../types";
import { 
  Play, Pause, SkipForward, SkipBack, Shuffle, Repeat, 
  Volume2, VolumeX, FlameKindling, Radio, Music4, Zap, Activity
} from "lucide-react";

interface ControlDeckProps {
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrev: () => void;
  isShuffle: boolean;
  onToggleShuffle: () => void;
  isRepeat: boolean;
  onToggleRepeat: () => void;
  
  volume: number;
  onVolumeChange: (val: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;

  eq: EqualizerSetting;
  onEQChange: (newEQ: EqualizerSetting) => void;
  
  metalizer: number;
  onMetalizerChange: (val: number) => void;

  playbackSpeed: number;
  onSpeedChange: (val: number) => void;

  visualizerMode: VisualizerMode;
  onVisualizerModeChange: (mode: VisualizerMode) => void;

  activePreset: EQPreset;
  onSelectPreset: (preset: EQPreset) => void;
}

export default function ControlDeck({
  isPlaying,
  onPlayPause,
  onNext,
  onPrev,
  isShuffle,
  onToggleShuffle,
  isRepeat,
  onToggleRepeat,
  volume,
  onVolumeChange,
  isMuted,
  onToggleMute,
  eq,
  onEQChange,
  metalizer,
  onMetalizerChange,
  playbackSpeed,
  onSpeedChange,
  visualizerMode,
  onVisualizerModeChange,
  activePreset,
  onSelectPreset,
}: ControlDeckProps) {

  // Equalizer single band handler
  const handleBandChange = (band: "bass" | "mid" | "treble", value: number) => {
    const updated = { ...eq, [band]: value };
    onEQChange(updated);
  };

  return (
    <div className="flex flex-col gap-5 text-slate-300" id="control-deck-deck">
      {/* Visualizer Selector */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-mono tracking-widest text-slate-400 uppercase flex items-center gap-1.5">
          <Activity size={12} className="text-slate-400" />
          Spectral Style
        </label>
        <div className="grid grid-cols-5 gap-1 bg-black/40 p-1.5 rounded-xl border border-white/5">
          {(["liquid", "bars", "spectrum", "circular", "wave"] as VisualizerMode[]).map((mode) => (
            <button
              key={mode}
              onClick={() => onVisualizerModeChange(mode)}
              id={`viz-${mode}`}
              className={`py-1 text-xs font-medium rounded-lg capitalize transition-all duration-200 ${
                visualizerMode === mode 
                  ? "bg-white/12 text-white font-semibold border-b border-white/20 shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Main Playback Controls Rows */}
      <div className="flex items-center justify-between bg-black/20 p-2.5 rounded-xl border border-white/5">
        {/* Shuffle Button */}
        <button
          onClick={onToggleShuffle}
          id="btn-shuffle"
          className={`p-2 rounded-lg transition-transform hover:scale-105 ${
            isShuffle ? "text-white bg-white/10" : "text-slate-400 hover:text-slate-200"
          }`}
          title="Shuffle Playlist"
        >
          <Shuffle size={16} />
        </button>

        {/* Previous */}
        <button 
          onClick={onPrev} 
          id="btn-prev"
          className="p-2 text-slate-400 hover:text-white transition-all hover:scale-110 active:scale-95"
        >
          <SkipBack size={18} />
        </button>

        {/* Master Play / Pause */}
        <button
          onClick={onPlayPause}
          id="btn-play-pause"
          className="w-12 h-12 rounded-full bg-gradient-to-b from-slate-100 to-slate-200 hover:from-white hover:to-slate-100 text-black flex items-center justify-center cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-all"
        >
          {isPlaying ? <Pause size={20} fill="black" /> : <Play size={20} fill="black" className="ml-1" />}
        </button>

        {/* Next */}
        <button 
          onClick={onNext} 
          id="btn-next"
          className="p-2 text-slate-400 hover:text-white transition-all hover:scale-110 active:scale-95"
        >
          <SkipForward size={18} />
        </button>

        {/* Repeat */}
        <button
          onClick={onToggleRepeat}
          id="btn-repeat"
          className={`p-2 rounded-lg transition-transform hover:scale-105 ${
            isRepeat ? "text-white bg-white/10" : "text-slate-400 hover:text-slate-200"
          }`}
          title="Repeat Track"
        >
          <Repeat size={16} />
        </button>
      </div>

      {/* Master Volume Slider */}
      <div className="flex items-center gap-3 bg-black/10 p-2 rounded-xl">
        <button onClick={onToggleMute} id="btn-mute" className="text-slate-400 hover:text-white transition-colors">
          {isMuted || volume === 0 ? <VolumeX size={15} /> : <Volume2 size={15} />}
        </button>
        <input
          type="range"
          min="0"
          max="100"
          value={isMuted ? 0 : volume * 100}
          onChange={(e) => onVolumeChange(parseFloat(e.target.value) / 100)}
          id="volume-slider"
          className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
        />
        <span className="text-[10px] font-mono text-slate-400 w-6 text-right">
          {Math.round((isMuted ? 0 : volume) * 100)}%
        </span>
      </div>

      {/* Acoustic Equalizer Section */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <label className="text-xs font-mono tracking-widest text-slate-400 uppercase flex items-center gap-1.5">
            <Radio size={12} className="text-slate-400" />
            Acoustic Equalizer
          </label>
          <span className="text-[10px] uppercase font-mono text-slate-400 bg-white/5 py-0.5 px-2 rounded-full border border-white/5">
            {activePreset}
          </span>
        </div>

        {/* Equalizer Profile Presets Selector */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-black/30 rounded-lg border border-white/5 text-[11px]">
          {(["flat", "bass", "vocals", "electronic"] as EQPreset[]).map((preset) => (
            <button
              key={preset}
              onClick={() => onSelectPreset(preset)}
              id={`preset-${preset}`}
              className={`py-1 rounded capitalize transition-all ${
                activePreset === preset 
                  ? "bg-white/10 text-white font-medium" 
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              {preset}
            </button>
          ))}
        </div>

        {/* 3-Band Slider Sliders */}
        <div className="grid grid-cols-3 gap-3 bg-black/25 p-3 rounded-xl border border-white/5">
          {/* Bass Band */}
          <div className="flex flex-col items-center gap-1.5">
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={eq.bass}
              onChange={(e) => handleBandChange("bass", parseInt(e.target.value))}
              id="slider-eq-bass"
              className="vertical-slider h-20 -my-1 w-1 bg-slate-800 rounded-lg appearance-none cursor-row-resize"
              style={{ writingMode: "bt-lr", WebkitAppearance: "slider-vertical" } as any}
            />
            <span className="text-[10px] font-mono text-slate-400">Bass</span>
            <span className="text-[10px] font-mono font-medium text-slate-300">{eq.bass > 0 ? `+${eq.bass}` : eq.bass}dB</span>
          </div>

          {/* Mid Band */}
          <div className="flex flex-col items-center gap-1.5">
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={eq.mid}
              onChange={(e) => handleBandChange("mid", parseInt(e.target.value))}
              id="slider-eq-mid"
              className="vertical-slider h-20 -my-1 w-1 bg-slate-800 rounded-lg appearance-none cursor-row-resize"
              style={{ writingMode: "bt-lr", WebkitAppearance: "slider-vertical" } as any}
            />
            <span className="text-[10px] font-mono text-slate-400">Mid</span>
            <span className="text-[10px] font-mono font-medium text-slate-300">{eq.mid > 0 ? `+${eq.mid}` : eq.mid}dB</span>
          </div>

          {/* Treble Band */}
          <div className="flex flex-col items-center gap-1.5">
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={eq.treble}
              onChange={(e) => handleBandChange("treble", parseInt(e.target.value))}
              id="slider-eq-treble"
              className="vertical-slider h-20 -my-1 w-1 bg-slate-800 rounded-lg appearance-none cursor-row-resize"
              style={{ writingMode: "bt-lr", WebkitAppearance: "slider-vertical" } as any}
            />
            <span className="text-[10px] font-mono text-slate-400">Treb</span>
            <span className="text-[10px] font-mono font-medium text-slate-300">{eq.treble > 0 ? `+${eq.treble}` : eq.treble}dB</span>
          </div>
        </div>
      </div>

      {/* Custom Reverb / Metalizer Level effect slider */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between text-xs">
          <label className="font-mono tracking-widest text-slate-400 uppercase flex items-center gap-1.5">
            <Zap size={12} className="text-slate-400" />
            Liquid Metal Comb-Filter
          </label>
          <span className="text-[10px] font-mono text-slate-300">{Math.round(metalizer * 100)}%</span>
        </div>
        <div className="flex items-center gap-3 bg-black/20 px-3 py-2.5 rounded-xl border border-white/5">
          <FlameKindling size={14} className={`${metalizer > 0 ? "text-slate-200 animate-pulse" : "text-slate-600"}`} />
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={metalizer}
            onChange={(e) => onMetalizerChange(parseFloat(e.target.value))}
            id="metalizer-slider"
            className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>

      {/* Speed Dial Controllers */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-mono tracking-widest text-slate-400 uppercase flex items-center gap-1.5">
          <Music4 size={12} className="text-slate-400" />
          Tempo Speed (Slow-Reverb / Nightcore)
        </label>
        <div className="grid grid-cols-4 gap-1 bg-black/40 p-1 rounded-xl border border-white/5 text-[10px]">
          {[0.5, 1.0, 1.3, 1.7].map((speed) => (
            <button
              key={speed}
              onClick={() => onSpeedChange(speed)}
              id={`speed-${speed}`}
              className={`py-1.5 rounded-lg font-mono transition-all ${
                playbackSpeed === speed 
                  ? "bg-white/10 text-white font-semibold" 
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {speed === 1.0 ? "Normal" : `${speed}x`}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
