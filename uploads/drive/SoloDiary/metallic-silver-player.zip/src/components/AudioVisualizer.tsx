/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from "react";
import { globalAudioEngine } from "../utils/AudioEngine";
import { VisualizerMode } from "../types";

interface AudioVisualizerProps {
  mode: VisualizerMode;
  isActive: boolean;
  accentColor?: string; // custom metallic glare override
}

export default function AudioVisualizer({ mode, isActive, accentColor = "#c0c0c0" }: AudioVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number | null>(null);
  const [dimensions, setDimensions] = useState({ width: 300, height: 120 });

  // Handle ResizeObserver responsive canvas sizing inside containers
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      // Guarantee minimal rendering size
      setDimensions({
        width: Math.max(100, Math.floor(width)),
        height: Math.max(40, Math.floor(height)),
      });
    });

    resizeObserver.observe(container);
    return () => {
      resizeObserver.disconnect();
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let rotationAngle = 0;

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);

      const dpr = window.devicePixelRatio || 1;
      const width = dimensions.width;
      const height = dimensions.height;

      // Clear with elegant translucent dark mask keeping traces of fading momentum (phosphor decay effect)
      ctx.fillStyle = "rgba(10, 10, 10, 0.22)";
      ctx.fillRect(0, 0, width, height);

      // Fetch spectrum array buffers
      const { freqData, waveData } = globalAudioEngine.getAnalyserData();
      
      const hasAudio = freqData.length > 0 && waveData.length > 0;
      
      // Let's fabricate gorgeous fallback wave animation if no audio active but player is marked active
      let finalFreq = new Uint8Array(256);
      let finalWave = new Uint8Array(256);

      if (hasAudio && isActive) {
        // Real audio spectrum
        finalFreq = freqData;
        finalWave = waveData;
      } else {
        // Fallback procedural visual patterns for idle states or custom generative sound fallback offline
        const time = Date.now() * 0.003;
        for (let i = 0; i < 256; i++) {
          if (isActive) {
            // Smooth natural oscillation for active fallback style
            finalFreq[i] = Math.max(0, Math.floor(60 + Math.sin(time + i * 0.05) * 40 + Math.cos(time * 0.7 - i * 0.02) * 20));
            finalWave[i] = Math.floor(128 + Math.sin(time * 2 + i * 0.1) * 35);
          } else {
            // Dormant micro-pulsing static lines
            finalFreq[i] = Math.max(0, Math.floor(5 + Math.sin(time + i * 0.1) * 4));
            finalWave[i] = Math.floor(128 + Math.cos(i * 0.2) * 2);
          }
        }
      }

      // Compute general audio energy
      let totalEnergy = 0;
      for (let i = 0; i < 64; i++) {
        totalEnergy += finalFreq[i];
      }
      const energyLevel = totalEnergy / 64; // Average bass/mid value (0-255)
      const pulseMultiplier = 1.0 + (energyLevel / 255) * 0.35; // Modulate scale factor

      // Render styles
      if (mode === "liquid") {
        // LIQUID MERCURY / METALLIC GALLIUM WAVE FORM
        ctx.save();
        ctx.translate(width / 2, height / 2);

        // Multiple overlaying organic circles morphing
        const numBlobs = 3;
        for (let b = 0; b < numBlobs; b++) {
          const orbitOffset = b * (Math.PI / numBlobs) + (Date.now() * 0.0005);
          const baseRadius = Math.min(width, height) * 0.28 * pulseMultiplier + (b * 6);
          
          ctx.beginPath();
          const points = 32;
          for (let p = 0; p <= points; p++) {
            const angle = (p / points) * Math.PI * 2;
            // Map freq index
            const freqIdx = Math.floor((p % (points / 2)) * (finalFreq.length / (points / 2)));
            const amp = finalFreq[freqIdx] ? (finalFreq[freqIdx] / 255) * 18 : 3;
            
            // Warp points based on frequency and time
            const r = baseRadius + Math.sin(angle * 6 + orbitOffset * 4) * amp + Math.cos(angle * 3 - orbitOffset * 2) * (amp * 0.5);
            const x = Math.cos(angle) * r;
            const y = Math.sin(angle) * r;

            if (p === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.closePath();
          
          // Render metallic silver gradient overlays with distinct blending
          const grad = ctx.createRadialGradient(0, 0, baseRadius * 0.2, 0, 0, baseRadius * 1.5);
          if (b === 0) {
            grad.addColorStop(0, "rgba(235, 235, 235, 0.45)");
            grad.addColorStop(0.5, "rgba(180, 180, 180, 0.25)");
            grad.addColorStop(1, "rgba(100, 100, 100, 0.0)");
          } else if (b === 1) {
            grad.addColorStop(0, "rgba(255, 255, 255, 0.15)");
            grad.addColorStop(0.7, "rgba(160, 160, 160, 0.1)");
            grad.addColorStop(1, "rgba(40, 40, 40, 0.0)");
          } else {
            grad.addColorStop(0, "rgba(220, 220, 220, 0.3)");
            grad.addColorStop(0.9, "rgba(140, 140, 140, 0.05)");
            grad.addColorStop(1, "rgba(0, 0, 0, 0)");
          }
          ctx.fillStyle = grad;
          ctx.fill();

          // Glass edge highlighting
          ctx.strokeStyle = `rgba(230, 230, 230, ${0.45 / (b + 1)})`;
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }

        ctx.restore();
      } 
      
      else if (mode === "bars") {
        // ELECTRONIC GLOWING SILVER BARS
        const barWidth = Math.max(1.5, (width / 40) - 2);
        const gap = 3;
        const totalBars = Math.floor(width / (barWidth + gap));
        const startX = (width - (totalBars * (barWidth + gap))) / 2;

        for (let i = 0; i < totalBars; i++) {
          // Logarithmically map or sample frequency spectrum
          const bin = Math.floor((i / totalBars) * 110);
          const val = finalFreq[bin];
          const barHeight = (val / 255) * height * 0.82;

          const x = startX + i * (barWidth + gap);
          const y = height - barHeight - 4;

          // Draw dual gloss bar gradients
          const gradient = ctx.createLinearGradient(x, y, x, height);
          gradient.addColorStop(0, "#ffffff"); // high bright crest
          gradient.addColorStop(0.2, accentColor === "#c0c0c0" ? "#e8e8e8" : accentColor);
          gradient.addColorStop(0.6, "#808080"); 
          gradient.addColorStop(1, "rgba(20, 20, 20, 0.1)"); // fading bottom

          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, [2, 2, 0, 0]);
          ctx.fill();

          // Floating neon dot on top of bass bars (cool cyber element)
          if (i % 3 === 0 && barHeight > 15) {
            ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
            ctx.fillRect(x, Math.max(2, y - 4), barWidth, 1.5);
          }
        }
      } 
      
      else if (mode === "spectrum") {
        // DOUBLE MIRROR WIDE ELECTRONIC SPECTRUM
        ctx.beginPath();
        const sliceWidth = width / 128;
        ctx.moveTo(0, height / 2);

        for (let i = 0; i < 128; i++) {
          const bin = Math.floor((i / 128) * 180);
          const amplitude = (finalFreq[bin] / 255) * height * 0.45;
          const x = i * sliceWidth;
          const y = (height / 2) - amplitude;

          ctx.lineTo(x, y);
        }

        // Mirror reflected line
        for (let i = 127; i >= 0; i--) {
          const bin = Math.floor((i / 128) * 180);
          const amplitude = (finalFreq[bin] / 255) * height * 0.45;
          const x = i * sliceWidth;
          const y = (height / 2) + amplitude;

          ctx.lineTo(x, y);
        }

        ctx.closePath();
        
        // Solid gloss silver gradient fill
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        gradient.addColorStop(0, "rgba(100, 100, 100, 0.05)");
        gradient.addColorStop(0.5, "rgba(235, 235, 235, 0.25)");
        gradient.addColorStop(1, "rgba(100, 100, 100, 0.05)");
        
        ctx.fillStyle = gradient;
        ctx.fill();

        ctx.strokeStyle = "rgba(255, 255, 255, 0.7)";
        ctx.lineWidth = 1;
        ctx.stroke();
      } 
      
      else if (mode === "circular") {
        // ORBIT RADIATING CYBER REACTOR
        ctx.save();
        ctx.translate(width / 2, height / 2);
        
        rotationAngle += isActive ? 0.005 : 0.001;
        ctx.rotate(rotationAngle);

        const radius = Math.min(width, height) * 0.24 * pulseMultiplier;
        const totalRays = 72;

        for (let i = 0; i < totalRays; i++) {
          const angle = (i / totalRays) * Math.PI * 2;
          
          // Wave amplitude
          const freqIdx = Math.floor((i / totalRays) * 128);
          const val = finalFreq[freqIdx];
          const rayLen = (val / 255) * 28 + 4;

          const xStart = Math.cos(angle) * radius;
          const yStart = Math.sin(angle) * radius;
          const xEnd = Math.cos(angle) * (radius + rayLen);
          const yEnd = Math.sin(angle) * (radius + rayLen);

          // Ray styling
          ctx.beginPath();
          ctx.moveTo(xStart, yStart);
          ctx.lineTo(xEnd, yEnd);
          ctx.strokeStyle = `rgba(180, 180, 180, ${0.15 + (val / 255) * 0.75})`;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Inner chrome core circle
        ctx.beginPath();
        ctx.arc(0, 0, radius - 2, 0, Math.PI * 2);
        const innerGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, radius);
        innerGrad.addColorStop(0, "rgba(30, 30, 30, 0.9)");
        innerGrad.addColorStop(0.7, "rgba(70, 70, 70, 0.8)");
        innerGrad.addColorStop(1, "rgba(210, 210, 210, 0.95)");
        
        ctx.fillStyle = innerGrad;
        ctx.fill();
        ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.restore();
      } 
      
      else {
        // OSCILLOSCOPE LIQUID SINE WAVE
        ctx.beginPath();
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = "rgba(255, 255, 255, 0.75)";
        
        const sliceWidth = width / 128;
        let x = 0;

        for (let i = 0; i < 128; i++) {
          const val = finalWave[i * 2] / 128.0; // 0.0 to 2.0
          const y = (val * height) / 2;

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }

          x += sliceWidth;
        }

        ctx.stroke();
      }
    };

    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isActive, mode, dimensions, accentColor]);

  return (
    <div ref={containerRef} className="w-full h-full relative" id="visualizer-container">
      <canvas
        ref={canvasRef}
        width={dimensions.width}
        height={dimensions.height}
        className="block rounded-xl border border-white/5 opacity-90 transition-opacity duration-300"
        id="visualizer-canvas"
      />
    </div>
  );
}
