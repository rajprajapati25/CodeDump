/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useRef } from "react";
import { Track, EqualizerSetting, EQPreset, VisualizerMode } from "./types";
import { globalAudioEngine } from "./utils/AudioEngine";
import MetallicPlayerCard from "./components/MetallicPlayerCard";
import ControlDeck from "./components/ControlDeck";
import PlaylistsView from "./components/PlaylistsView";
import { 
  Disc, Sliders, Volume2, HelpCircle, Flame, 
  CornerDownRight, CheckCircle2, ChevronRight, Share2, Info,
  Eye, EyeOff
} from "lucide-react";

const INITIAL_TRACKS: Track[] = [
  {
    id: "gen-ambient",
    title: "Liquid Silver Synthesis",
    artist: "Procedural Ambient Synth",
    duration: 360, // 6 minutes of generative endless chimes
    genre: "AMBIENT",
    isGenerative: true,
    generativeType: "chime",
    coverImage: "/src/assets/images/liquid_silver_cover_1781327598330.jpg",
  },
  {
    id: "gen-drone",
    title: "Mercury Gallium Core",
    artist: "Generative Dark Drone",
    duration: 480, // 8 minutes of detuned harmonic drone sweeps
    genre: "DRONE",
    isGenerative: true,
    generativeType: "drone",
    coverImage: "/src/assets/images/gallium_core_cover_1781327617149.jpg",
  },
  {
    id: "gen-beats",
    title: "Retro Silver Metallic Beat",
    artist: "Digital Drum Synthesizer",
    duration: 240, // 4 minutes of synthesized kicks, snare, lead
    genre: "BEATS",
    isGenerative: true,
    generativeType: "beat",
    coverImage: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&q=80&w=400",
  },
  {
    id: "gen-sparkles",
    title: "Stardust Shimmer Sparkles",
    artist: "High Frequency Pitch Engine",
    duration: 180, // 3 minutes of high shimmering bells
    genre: "SHIMMER",
    isGenerative: true,
    generativeType: "sparkle",
    coverImage: "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&q=80&w=400",
  },
  {
    id: "stream-lofi",
    title: "Neon Horizon Waves",
    artist: "Classic Electro-Acoustic Chill",
    duration: 372,
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    genre: "CHILLOUT",
    coverImage: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=400",
  },
  {
    id: "stream-cyber",
    title: "Cybernetic Glass Echoes",
    artist: "Deep Tech Atmosphere",
    duration: 502,
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    genre: "CYBERPUNK",
    coverImage: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=400",
  }
];

const PRESET_EQS: { [key in EQPreset]: EqualizerSetting } = {
  flat: { bass: 0, mid: 0, treble: 0 },
  bass: { bass: 8, mid: 1, treble: -3 },
  vocals: { bass: -4, mid: 7, treble: 3 },
  electronic: { bass: 6, mid: -1, treble: 5 },
  metalizer: { bass: -2, mid: 5, treble: 10 }
};

export default function App() {
  const [tracks, setTracks] = useState<Track[]>(() => {
    try {
      const savedAll = localStorage.getItem("silver_player_all_tracks");
      if (savedAll) {
        return JSON.parse(savedAll) as Track[];
      }
      const saved = localStorage.getItem("silver_player_custom_tracks");
      if (saved) {
        const parsed = JSON.parse(saved) as Track[];
        // Filter out any duplicates with INITIAL_TRACKS
        const filteredParsed = parsed.filter(pt => pt.userUploaded);
        return [...INITIAL_TRACKS, ...filteredParsed];
      }
    } catch {}
    return INITIAL_TRACKS;
  });

  const [currentTrack, setCurrentTrack] = useState<Track>(tracks[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [eq, setEQ] = useState<EqualizerSetting>({ bass: 1, mid: 0, treble: 1 });
  const [metalizer, setMetalizer] = useState(0.15);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [visualizerMode, setVisualizerMode] = useState<VisualizerMode>("liquid");
  const [activePreset, setActivePreset] = useState<EQPreset>("flat");
  const [activeNotes, setActiveNotes] = useState<{ note: string; freq: number; id: number }[]>([]);
  const [showVisualizer, setShowVisualizer] = useState(true);
  const [focusMode, setFocusMode] = useState(false);

  const currentTrackRef = useRef(currentTrack);
  useEffect(() => {
    currentTrackRef.current = currentTrack;
  }, [currentTrack]);

  // Sync Audio Engine values
  useEffect(() => {
    // Initial setup hooks
    globalAudioEngine.setOnTimeUpdate((time) => {
      setCurrentTime(time);
    });

    globalAudioEngine.setOnDurationChange((duration) => {
      if (duration && duration > 0) {
        const d = Math.round(duration);
        const currentId = currentTrackRef.current.id;
        setCurrentTrack(prev => prev.id === currentId ? { ...prev, duration: d } : prev);
        setTracks(prev => prev.map(t => t.id === currentId ? { ...t, duration: d } : t));
      }
    });

    globalAudioEngine.setOnTrackEnded(() => {
      handleNextTrack();
    });

    globalAudioEngine.setOnSynthNote((note, freq) => {
      // Monitor synthesized note triggers in real-time
      const newNote = { note, freq, id: Date.now() + Math.random() };
      setActiveNotes(prev => [newNote, ...prev.slice(0, 5)]);
    });

    // Apply defaults
    globalAudioEngine.setVolume(volume);
    globalAudioEngine.applyEqualizer(eq);
    globalAudioEngine.setMetalizerLevel(metalizer);
    globalAudioEngine.setPlaybackRate(playbackSpeed);

    // Initial load
    globalAudioEngine.loadTrack(currentTrack);

    return () => {
      globalAudioEngine.pause();
    };
  }, []);

  // Handle updates to volume
  useEffect(() => {
    globalAudioEngine.setVolume(isMuted ? 0 : volume);
  }, [volume, isMuted]);

  // Handle Updates to EQ
  useEffect(() => {
    globalAudioEngine.applyEqualizer(eq);
  }, [eq]);

  // Handle updates to Metalizer Reverb level
  useEffect(() => {
    globalAudioEngine.setMetalizerLevel(metalizer);
  }, [metalizer]);

  // Handle updates to Speed
  useEffect(() => {
    globalAudioEngine.setPlaybackRate(playbackSpeed);
  }, [playbackSpeed]);

  // Synchronize dynamic preset clicks
  const selectPreset = (preset: EQPreset) => {
    setActivePreset(preset);
    const presetEQ = PRESET_EQS[preset];
    setEQ(presetEQ);
    // If metalizer preset trigger metal slider full
    if (preset === "metalizer") {
      setMetalizer(0.85);
    } else {
      setMetalizer(0.15);
    }
  };

  const handleSelectTrack = (track: Track) => {
    setCurrentTrack(track);
    setCurrentTime(0);
    globalAudioEngine.loadTrack(track);
    
    // Automatically boot up context and play
    if (isPlaying) {
      globalAudioEngine.play();
    } else {
      setIsPlaying(true);
      globalAudioEngine.play();
    }
  };

  const handlePlayPause = () => {
    const nextState = !isPlaying;
    setIsPlaying(nextState);
    if (nextState) {
      globalAudioEngine.play();
    } else {
      globalAudioEngine.pause();
    }
  };

  const handleNextTrack = () => {
    let nextIndex = 0;
    if (isShuffle) {
      nextIndex = Math.floor(Math.random() * tracks.length);
    } else {
      const idx = tracks.findIndex(t => t.id === currentTrack.id);
      nextIndex = idx + 1 >= tracks.length ? 0 : idx + 1;
    }
    handleSelectTrack(tracks[nextIndex]);
  };

  const handlePrevTrack = () => {
    const idx = tracks.findIndex(t => t.id === currentTrack.id);
    let prevIndex = idx - 1 < 0 ? tracks.length - 1 : idx - 1;
    handleSelectTrack(tracks[prevIndex]);
  };

  const handleSeek = (secs: number) => {
    setCurrentTime(secs);
    globalAudioEngine.seek(secs);
  };

  // Drag and Drop implementation for local media uploads
  const handleUploadTrack = (file: File) => {
    // Generate URL blob
    const blobUrl = URL.createObjectURL(file);
    const isVideoFile = file.type.startsWith("video/") || file.name.toLowerCase().endsWith(".mp4");
    
    // Attempt parsing audio/video duration
    const mediaObj = isVideoFile ? document.createElement("video") : document.createElement("audio");
    mediaObj.src = blobUrl;
    
    const assembleTrack = (dur: number) => {
      const cleanName = file.name.replace(/\.[^/.]+$/, ""); // strip extension
      const newTrack: Track = {
        id: `user-track-${Date.now()}`,
        title: cleanName,
        artist: isVideoFile ? "Uploaded Video" : "Uploaded Audio",
        duration: Math.round(dur),
        url: blobUrl,
        genre: isVideoFile ? "VIDEO CLIP" : "LOCAL BEAT",
        userUploaded: true,
        isVideo: isVideoFile
      };

      const updatedPlaylist = [newTrack, ...tracks];
      setTracks(updatedPlaylist);
      handleSelectTrack(newTrack);

      // Save custom tracks and all tracks in localStorage for sessions
      try {
        const customUploadsOnly = updatedPlaylist.filter(t => t.userUploaded);
        localStorage.setItem("silver_player_custom_tracks", JSON.stringify(customUploadsOnly));
        localStorage.setItem("silver_player_all_tracks", JSON.stringify(updatedPlaylist));
      } catch (err) {
        console.warn("Storage upload tracking failed", err);
      }
    };

    mediaObj.addEventListener("loadedmetadata", () => {
      assembleTrack(mediaObj.duration || 180);
    });

    mediaObj.addEventListener("error", () => {
      // In case metadata parsing fails, fallback gracefully
      assembleTrack(210);
    });
  };

  // Keep track title edits in sync with list and preserve
  const handleUpdateTrackTitle = (id: string, newTitle: string) => {
    const updated = tracks.map(t => t.id === id ? { ...t, title: newTitle } : t);
    setTracks(updated);
    if (currentTrack.id === id) {
      setCurrentTrack(prev => ({ ...prev, title: newTitle }));
    }
    try {
      localStorage.setItem("silver_player_all_tracks", JSON.stringify(updated));
    } catch {}
  };

  // Keep track custom image updates in sync with list
  const handleUpdateTrackCover = (id: string, newCoverUrl: string) => {
    const updated = tracks.map(t => t.id === id ? { ...t, coverImage: newCoverUrl } : t);
    setTracks(updated);
    if (currentTrack.id === id) {
      setCurrentTrack(prev => ({ ...prev, coverImage: newCoverUrl }));
    }
    try {
      localStorage.setItem("silver_player_all_tracks", JSON.stringify(updated));
    } catch {}
  };

  // Removing standard custom uploaded track
  const handleRemoveTrack = (id: string) => {
    const filtered = tracks.filter(t => t.id !== id);
    setTracks(filtered);

    // If active track deleted, fallback to the 0 index track
    if (currentTrack.id === id) {
      handleSelectTrack(filtered[0]);
    }

    try {
      const customOnly = filtered.filter(t => t.userUploaded);
      localStorage.setItem("silver_player_custom_tracks", JSON.stringify(customOnly));
      localStorage.setItem("silver_player_all_tracks", JSON.stringify(filtered));
    } catch {}
  };

  return (
    <main className="main-container scroll-smooth" id="applet-main-container">
      
      {/* Immersive glowing metal tabletop overlays */}
      <div className="absolute top-1/4 left-1/4 w-[380px] h-[380px] bg-sky-200/5 blur-[120px] rounded-full pointer-events-none z-0 rotate-12" />
      <div className="absolute bottom-1/4 right-1/4 w-[450px] h-[450px] bg-slate-300/[0.04] blur-[150px] rounded-full pointer-events-none z-0 -rotate-45" />

      {/* Decorative metal texture background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none z-0" />

      {/* Primary Header Section */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 z-10 shrink-0 border-b border-white/[0.05] bg-black/10 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-300 to-slate-100 flex items-center justify-center shadow-md border border-white/20">
            <Disc className="text-black animate-spin" style={{ animationDuration: "12s" }} size={20} />
          </div>
          <div>
            <h1 className="text-xl font-bold font-sans tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent flex items-center gap-2">
              Metallic Silver Player
            </h1>
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-500 mt-0.5">
              Low-Latency Audio Synth & Rippling Liquid Galvanizer
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* AudioVisualizer Toggle Button */}
          <button
            onClick={() => setShowVisualizer(!showVisualizer)}
            id="toggle-audio-visualizer"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs transition-colors cursor-pointer ${
              showVisualizer 
                ? "bg-slate-100 hover:bg-white text-black border-slate-200 font-medium" 
                : "bg-white/5 hover:bg-white/10 text-slate-300 border-white/5"
            }`}
            title="Toggle AudioVisualizer Overlay"
          >
            <span>{showVisualizer ? "✦ AudioVisualizer: ON" : "✧ AudioVisualizer: OFF"}</span>
          </button>

          {/* Focus Mode Toggle Button */}
          <button
            onClick={() => setFocusMode(!focusMode)}
            id="toggle-focus-mode"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs transition-all cursor-pointer ${
              focusMode 
                ? "bg-indigo-500/20 hover:bg-indigo-500/35 text-indigo-200 border-indigo-500/30 font-medium" 
                : "bg-white/5 hover:bg-white/10 text-slate-300 border-white/5"
            }`}
            title={focusMode ? "Show Sidebar & Controls" : "Hide Everything Except Metallic Card"}
          >
            {focusMode ? (
              <>
                <Eye size={13} className="text-indigo-300" />
                <span>Show Controls</span>
              </>
            ) : (
              <>
                <EyeOff size={13} className="text-slate-400" />
                <span>Focus Mode</span>
              </>
            )}
          </button>

          <span className="hidden md:inline text-[10px] font-mono text-slate-400 bg-white/5 py-1 px-3 rounded-full border border-white/[0.04]">
            16-BIT FEEDBACK CODES / DUAL CH
          </span>
        </div>
      </div>


      {/* Chief Grid Layout Stage */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start z-10" id="main-player-grid">
        
        {/* Left column: Playlist collection glass card */}
        <div className={`${focusMode ? "hidden" : "lg:col-span-4 h-full flex flex-col gap-6 order-2 lg:order-1"}`} id="left-column-deck">
          <div className="glass-panel p-5 rounded-2xl flex flex-col border border-white/15 h-full shadow-lg">
            <PlaylistsView
              tracks={tracks}
              currentTrack={currentTrack}
              onSelectTrack={handleSelectTrack}
              onUploadTrack={handleUploadTrack}
              onRemoveTrack={handleRemoveTrack}
            />
          </div>

          <div className="glass-panel p-4 rounded-2xl border border-white/10 text-[11px] text-slate-500 font-mono space-y-2" id="left-bottom-box">
            <p className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">Device Parameters</p>
            <div className="flex justify-between items-center bg-black/25 px-2.5 py-1.5 rounded border border-white/5">
              <span>Decoder Platform</span>
              <span className="text-slate-300">Vite React AudioContext v2</span>
            </div>
            <div className="flex justify-between items-center bg-black/25 px-2.5 py-1.5 rounded border border-white/5">
              <span>Channel Synthesis</span>
              <span className="text-slate-300">2-Channel Discrete</span>
            </div>
            <div className="flex justify-between items-center bg-black/25 px-2.5 py-1.5 rounded border border-white/5">
              <span>Plate Mode Resonance</span>
              <span className="text-slate-300">Metallic Comb Filter Loop</span>
            </div>
          </div>
        </div>

        {/* Center column: Gorgeous Ripple border iPod Card */}
        <div className={`${focusMode ? "col-span-12 flex justify-center py-8 h-full items-center z-20" : "lg:col-span-4 flex justify-center py-2 h-full items-center order-1 lg:order-2"}`} id="middle-column-deck">
          <MetallicPlayerCard
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onPlayPause={handlePlayPause}
            visualizerMode={visualizerMode}
            currentTime={currentTime}
            onSeek={handleSeek}
            onUpdateTitle={handleUpdateTrackTitle}
            onUpdateCoverImage={handleUpdateTrackCover}
            onNext={handleNextTrack}
            onPrev={handlePrevTrack}
            showVisualizer={showVisualizer}
          />
        </div>

        {/* Right column: Equalizer and metal feedback settings */}
        <div className={`${focusMode ? "hidden" : "lg:col-span-4 h-full order-3 lg:order-3"}`} id="right-column-deck">
          <div className="glass-panel p-5 rounded-2xl border border-white/15 shadow-lg">
            <ControlDeck
              isPlaying={isPlaying}
              onPlayPause={handlePlayPause}
              onNext={handleNextTrack}
              onPrev={handlePrevTrack}
              isShuffle={isShuffle}
              onToggleShuffle={() => setIsShuffle(!isShuffle)}
              isRepeat={isRepeat}
              onToggleRepeat={() => setIsRepeat(!isRepeat)}
              
              volume={volume}
              onVolumeChange={setVolume}
              isMuted={isMuted}
              onToggleMute={() => setIsMuted(!isMuted)}
              
              eq={eq}
              onEQChange={setEQ}
              
              metalizer={metalizer}
              onMetalizerChange={setMetalizer}
              
              playbackSpeed={playbackSpeed}
              onSpeedChange={setPlaybackSpeed}

              visualizerMode={visualizerMode}
              onVisualizerModeChange={setVisualizerMode}

              activePreset={activePreset}
              onSelectPreset={selectPreset}
            />
          </div>
        </div>

      </div>

      {/* Footer Branding Line */}
      <div className="w-full py-6 mt-auto text-center border-t border-white/[0.05] z-10 bg-black/30 backdrop-blur-md">
        <p className="text-[11px] font-mono uppercase tracking-widest text-slate-500 flex items-center justify-center gap-1.5">
          <span>Metallic Silver Player Console</span>
          <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-ping" />
          <span>Rippling Galvanizer Engine online</span>
        </p>
      </div>

    </main>
  );
}
