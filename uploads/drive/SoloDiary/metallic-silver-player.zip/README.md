# Metallic Silver Player

<p align="center">
  <img src="src/assets/images/liquid_silver_cover_1781327598330.jpg" alt="Metallic Silver Player Icon / Banner" width="200" style="border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); border: 2px solid rgba(255,255,255,0.15);" />
</p>

A high-fidelity digital audio / video player and procedural generative synthesizer wrapper encased in a dramatic, responsive, rippling electric liquid-silver border effect. Built with modern React, TypeScript, and the Web Audio API, this application pairs premium interactive visuals, raw spectrum analysis, and customizable analog parametric controls into a single elegant screen.

---

## 🎨 Design Philosophy & Features

* **Liquid Mercury Aesthetics**: Encased in an organically rippling border powered by custom SVG displacement filters and smooth multi-layered keyframe transitions.
* **Unified Video & Audio Playback**: Supports both raw audio streaming, procedural synth generation, and local drag-and-drop or file upload of MP3, WAV, AAC, and MP4 video files. When playing video, the artwork panel converts seamlessly into a modular, responsive screen-fitted visualizer frame.
* **Dual Generative Synthesizers & Streams**: Includes custom built-in generative engines (Lofi Chimes, Dark Drone, Metallic Percussion, Shimmer Sparkles) alongside standard streaming feeds.
* **Responsive Visualizers**: Multi-mode real-time interactive canvas visualizer displaying physical frequencies or raw wave patterns beneath the music or video track.
* **Custom Parametric Tuning**: Built-in 5-band equalizer, parametric audio control deck, variable play speed (from 0.5x to 2.0x), and preset selectors (Bass Boost, Vocals, Electronic, Metalizer).
* **Precise Seek Synchronization**: A fully custom scrubbed progress bar ensuring perfect time alignment and zero lag, engineered carefully across both audio contexts and rendering frames.
* **Dynamic Title Editing & Custom Cover Art**: Inline track renaming and active artwork replacement with responsive manual crop/URL capabilities.

---

## 🛠️ Tech Stack & Libraries

* **Framework**: React 18+ (bundled with Vite)
* **Language**: TypeScript (Strict Typings)
* **Styling**: Tailwind CSS
* **Animations**: Motion (framer-motion) & CSS SVG Filter Displacement Effects
* **Icons**: [Lucide React](https://lucide.dev)
* **Audio Processing**: Native Web Audio API (AudioContext, GainNode, BiquadFilterNodes, AnalyserNode)
* **Rendering**: Canvas 2D API for high-frequency spectrum analysis

---

## 📂 File Structure

```text
/
├── public/                 # Static assets
├── src/
│   ├── assets/             # Global visual and image media
│   │   └── images/         # Futuristic cover photos and liquid silver presets
│   ├── components/         # Highly modular, fully typed view elements
│   │   ├── AudioVisualizer.tsx     # Frequency spectrum & wave visualizer canvas
│   │   ├── ControlDeck.tsx         # EQ presets, sliders, and audio pitch/speed tools
│   │   ├── MetallicPlayerCard.tsx  # Central liquid-silver card wrapper & video stage
│   │   └── PlaylistsView.tsx      # Interactive playlist uploads & metadata matching
│   ├── utils/
│   │   └── AudioEngine.ts          # Low-latency client audio node architecture
│   ├── App.tsx             # Main layout, coordinate grids, and state synchronization
│   ├── index.css           # Global typography definitions and theme styles
│   ├── main.tsx            # DOM node entry point
│   └── types.ts            # Core data contracts (Track, EQPreset, VisualizerMode)
├── tsconfig.json           # Compiler rules
├── vite.config.ts          # Bundles, build configs, and server rules
├── package.json            # Scripts and dependencies
└── README.md               # Documentation
```

---

## 📸 Screenshots

<p align="center">
  <em>(Add custom application screenshot here)</em><br />
  <img src="src/assets/images/gallium_core_cover_1781327617149.jpg" alt="Metallic Silver Player Interface Preview" width="600" style="border-radius: 12px; margin-top: 15px; border: 1px solid rgba(255,255,255,0.1);" />
</p>

---

## 🚀 Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run in Development Mode**:
   ```bash
   npm run dev
   ```

3. **Build Code for Production**:
   ```bash
   npm run build
   ```

---

## 📄 License & Software Standards

This project is licensed under the Apache License, Version 2.0.

```text
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
```
